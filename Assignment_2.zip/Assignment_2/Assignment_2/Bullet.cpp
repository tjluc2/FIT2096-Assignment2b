#include "Bullet.h"

Bullet::Bullet()
{

}

Bullet::Bullet(Mesh* mesh, Shader* shader, Texture* texture, Vector3 position, int damage, GameWorld* gameWorld) :
	PhysicsObject(mesh, shader, texture, position)
{
	m_moveSpeed = 0.8f;
	m_friction = 0.08f;
	m_damage = damage;
	m_gameWorld = gameWorld;

	inUse = false;

	m_boundingBox = CBoundingBox(m_position + m_mesh->GetMin(), m_position + m_mesh->GetMax());
} 

void Bullet::Update(float timestep)
{
	m_boundingBox.SetMin(m_position + m_mesh->GetMin());
	m_boundingBox.SetMax(m_position + m_mesh->GetMax());

	PhysicsObject::Update(timestep);
}

void Bullet::shoot(Vector3 target)
{
	ApplyForce(target * m_moveSpeed);
}

void Bullet::setReuse() 
{
	inUse = false;
	m_position = Vector3(0, -1, 0);
	m_velocity = Vector3::Zero;
}

