#ifndef BULLET_H
#define BULLET_H

#include "PhysicsObject.h"
#include "GameWorld.h"

class Bullet : public PhysicsObject
{
private:
	CBoundingBox m_boundingBox;
	GameWorld* m_gameWorld;
	bool inUse;
	float m_moveSpeed;
	float m_friction;
	int m_damage;
public:
	Bullet();
	Bullet(Mesh* mesh, Shader* shader, Texture* texture, Vector3 position, int damage, GameWorld* gameWorld);
	void Update(float timestep);

	bool getUsed() { return inUse; }
	void setUsed() { inUse = true; }
	void setReuse();
	void shoot(Vector3 target);
	int getDamage() { return m_damage; }

	CBoundingBox GetBounds() { return m_boundingBox; }
};

#endif
