#include "CollisionManager.h"

CollisionManager::CollisionManager(Player* player, std::vector<Monster*>* monsters, std::vector<DynamicObject*>* health, std::vector<Bullet*>* bullet, 
	std::vector<Bullet*>* monsterBullets, std::vector<DynamicObject*>* ammoBlocks, GameWorld* gameWorld)
{
	m_player = player;
	m_monsters = monsters;
	m_health = health;
	m_bullets = bullet;
	monster_bullets = monsterBullets;
	m_ammoBlocks = ammoBlocks;
	m_gameWorld = gameWorld;

	int x = m_gameWorld->GetXSize();
	int z = m_gameWorld->GetZSize();

	// Clear our arrays to 0 (NULL)
	memset(m_currentCollisions, 0, sizeof(m_currentCollisions));
	memset(m_previousCollisions, 0, sizeof(m_previousCollisions));

	m_nextCurrentCollisionSlot = 0;
}

void CollisionManager::CheckCollisions()
{
	PlayerMonster();
	PlayerHealth();
	MonsterBullet();
	PlayerBullet();
	PlayerAmmo();
	PlayerWall();
	MonsterWall();
	PlayerObstacle();
	MonsterObstacle();
	BulletObstacle();

	// Move all current collisions into previous
	memcpy(m_previousCollisions, m_currentCollisions, sizeof(m_currentCollisions));

	// Clear out current collisions
	memset(m_currentCollisions, 0, sizeof(m_currentCollisions));

	// Now current collisions is empty, we'll start adding from the start again
	m_nextCurrentCollisionSlot = 0;

}

bool CollisionManager::ArrayContainsCollision(GameObject* arrayToSearch[], GameObject* first, GameObject* second)
{
	// See if these two GameObjects appear one after the other in specified collisions array
	// Stop one before length so we don't overrun as we'll be checking two elements per iteration
	for (int i = 0; i < MAX_ALLOWED_COLLISIONS - 1; i += 2)
	{
		if ((arrayToSearch[i] == first && arrayToSearch[i + 1] == second) ||
			arrayToSearch[i] == second && arrayToSearch[i + 1] == first)
		{
			return true;
		}
	}

	// These objects were not colliding last frame
	return false;
}

void CollisionManager::AddCollision(GameObject* first, GameObject* second)
{
	// Add the two colliding objects to the current collisions array
	// We keep track of the next free slot so no searching is required
	m_currentCollisions[m_nextCurrentCollisionSlot] = first;
	m_currentCollisions[m_nextCurrentCollisionSlot + 1] = second;

	m_nextCurrentCollisionSlot += 2;
}

void CollisionManager::PlayerMonster()
{
	//Check if player is colliding with monster
	Player* player = m_player;
	CBoundingBox playerBounds = player->GetBounds();
	
	for (int j = 0; j < m_monsters->size(); j++) 
	{

		Monster* monster = (*m_monsters)[j];
		CBoundingBox monsterBounds = monster->GetBounds();
		
		bool isColliding = CheckCollision(playerBounds, monsterBounds);

		bool wasColliding = ArrayContainsCollision(m_previousCollisions, player, monster);

		if (isColliding)
		{
			AddCollision(player, monster);

			if (!wasColliding) {
				int currHealth = player->GetHealth();
				player->SetHealth(currHealth);					//Player dies
			}
		} 
	} 
}

void CollisionManager::PlayerHealth()
{
	// Check player against health capsule
	Player* player = m_player;
	CBoundingBox playerBounds = player->GetBounds();

	for (int j = 0; j < m_health->size(); j++)
	{
		DynamicObject* health = (*m_health)[j];
		CBoundingBox healthBounds = health->GetBounds();

		bool isColliding = CheckCollision(playerBounds, healthBounds);

		bool wasColliding = ArrayContainsCollision(m_previousCollisions, player, health);

		if (isColliding)
		{
			AddCollision(player, health);				

			if (!wasColliding)
			{
				m_player->OnHealthCollisionEnter(health);			//Increase player health
				health->setUsed();
			}
		}
	}
}

void CollisionManager::MonsterBullet()
{
	//Check if bullet collides with monster
	for (int i = 0; i < m_monsters->size(); i++)
	{
		for (int j = 0; j < m_bullets->size(); j++)
		{
			Monster* monster = (*m_monsters)[i];
			CBoundingBox monsterBounds = monster->GetBounds();

			Bullet* bullet = (*m_bullets)[j];
			CBoundingBox bulletBounds = bullet->GetBounds();

			bool isColliding = CheckCollision(monsterBounds, bulletBounds);

			bool wasColliding = ArrayContainsCollision(m_previousCollisions, monster, bullet);

			if (isColliding)
			{
				AddCollision(monster, bullet);
				
				if (!wasColliding) {
					monster->OnBulletCollisionEnter(bullet);			//Monster takes damage
				}
			}
		}
	}
}

void CollisionManager::PlayerBullet()
{
	//Check if bullet collides with player
	Player* player = m_player;
	CBoundingBox playerBounds = player->GetBounds();


	for (int j = 0; j < monster_bullets->size(); j++)
	{
		Bullet* monster_bullet = (*monster_bullets)[j];
		CBoundingBox bulletBounds = monster_bullet->GetBounds();

		bool isColliding = CheckCollision(playerBounds, bulletBounds);

		bool wasColliding = ArrayContainsCollision(m_previousCollisions, player, monster_bullet);

		if (isColliding)
		{
			AddCollision(player, monster_bullet);
			
			if (!wasColliding)
			{
				int damage = monster_bullet->getDamage();
				player->SetHealth(damage);			//Player takes damage
			}
		}
	}
}

void CollisionManager::PlayerAmmo()
{
	//Check if bullet collides with player
	Player* player = m_player;
	CBoundingBox playerBounds = player->GetBounds();


	for (int j = 0; j < m_ammoBlocks->size(); j++)
	{
		DynamicObject* ammoBlock = (*m_ammoBlocks)[j];
		CBoundingBox ammoBounds = ammoBlock->GetBounds();

		bool isColliding = CheckCollision(playerBounds, ammoBounds);

		bool wasColliding = ArrayContainsCollision(m_previousCollisions, player, ammoBlock);

		if (isColliding)
		{
			AddCollision(player, ammoBlock);

			if (!wasColliding)
			{
				//Increase players amount of bullets
				int bullets_left = m_player->GetBulletsLeft();
				if (bullets_left <= 18) {
					ammoBlock->setUsed();
					m_player->SetBullets(2);				//Give player 2 bullets
				}
			}
		}
	}
}

void CollisionManager::PlayerWall()
{
	//Check if player collides with wall
	Player* player = m_player;
	CBoundingBox playerBounds = player->GetBounds();
	int x = m_gameWorld->GetXSize();
	int z = m_gameWorld->GetZSize();

	std::vector<Tile*> tiles = m_gameWorld->GetWallTiles();
	
	//Only checks if player is near wall
	if (m_player->GetPosition().x < 2 || m_player->GetPosition().x > x-2) 
	{
		for (int i = 0; i < tiles.size(); i++)
		{
			if ((tiles[i]->GetPosition().x < 2) || (tiles[i]->GetPosition().x > x-2)) {
				Tile* wallTile = (tiles)[i];
				CBoundingBox tileBounds = wallTile->GetBounds();

				bool isColliding = CheckCollision(playerBounds, tileBounds);

				bool wasColliding = ArrayContainsCollision(m_previousCollisions, wallTile, player);

				if (isColliding)
				{
					AddCollision(wallTile, player);

					if (!wasColliding)
					{
						player->OnWallCollisionEnter(wallTile, m_gameWorld->GetXSize(), m_gameWorld->GetZSize());
					}
				}
			}
		}
	}

	if ((m_player->GetPosition().z < 2) || (m_player->GetPosition().z > z - 2))
	{
		for (int i = 0; i < tiles.size(); i++)
		{
			if ((tiles[i]->GetPosition().z < 2) || (tiles[i]->GetPosition().z > z - 2)) {
				Tile* wallTile = (tiles)[i];
				CBoundingBox tileBounds = wallTile->GetBounds();

				bool isColliding = CheckCollision(playerBounds, tileBounds);

				bool wasColliding = ArrayContainsCollision(m_previousCollisions, wallTile, player);

				if (isColliding)
				{
					AddCollision(wallTile, player);

					if (!wasColliding)
					{
						player->OnWallCollisionEnter(wallTile, m_gameWorld->GetXSize(), m_gameWorld->GetZSize());
					}
				}
			}
		}
	}
}

void CollisionManager::MonsterWall()
{
	//Check if monster collides with wall
	std::vector<Tile*> tiles = m_gameWorld->GetWallTiles();

	for (int i = 0; i < m_monsters->size(); i++)
	{
		Monster* monster = (*m_monsters)[i];
		CBoundingBox monsterBounds = monster->GetBounds();

		if ((monster->GetPosition().x < 2) || (monster->GetPosition().x < x - 2))
		{
			if ((tiles[i]->GetPosition().x < 2) || (tiles[i]->GetPosition().x > x - 2))
			{
				Tile* wallTile = (tiles)[i];
				CBoundingBox tileBounds = wallTile->GetBounds();

				bool isColliding = CheckCollision(monsterBounds, tileBounds);

				bool wasColliding = ArrayContainsCollision(m_previousCollisions, wallTile, monster);

				if (isColliding)
				{
					AddCollision(wallTile, monster);

					if (!wasColliding)
					{
						monster->OnWallCollisionEnter(wallTile, m_gameWorld->GetXSize(), m_gameWorld->GetZSize());
					}
				}
			}
			if ((tiles[i]->GetPosition().z < 2) || (tiles[i]->GetPosition().z > z - 2)) {
				Tile* wallTile = (tiles)[i];
				CBoundingBox tileBounds = wallTile->GetBounds();

				bool isColliding = CheckCollision(monsterBounds, tileBounds);

				bool wasColliding = ArrayContainsCollision(m_previousCollisions, wallTile, monster);

				if (isColliding)
				{
					AddCollision(wallTile, monster);

					if (!wasColliding)
					{
						monster->OnWallCollisionEnter(wallTile, m_gameWorld->GetXSize(), m_gameWorld->GetZSize());
					}
				}
			}
		}
	}

}

void CollisionManager::PlayerObstacle()
{
	//Checks if player collides with obstacle
	std::vector<Tile*> m_obstacles = m_gameWorld->GetObstacles();
	Player* player = m_player;
	CBoundingBox playerBounds = player->GetBounds();

	for (int i = 0; i < m_obstacles.size(); i++)
	{
		Tile* obstacle = (m_obstacles)[i];
		CBoundingBox obstacleBounds = obstacle->GetBounds();

		bool isColliding = CheckCollision(obstacleBounds, playerBounds);
		bool wasColliding = ArrayContainsCollision(m_previousCollisions, obstacle, player);

		if (isColliding) 
		{
			AddCollision(obstacle, player);

			if (wasColliding)
			{
				player->OnObstacleCollisionEnter(obstacle);
			}
		}
	}
}

void CollisionManager::MonsterObstacle()
{
	//Checks if monster collides with obstacle
	std::vector<Tile*> m_obstacles = m_gameWorld->GetObstacles();

	for (int i = 0; i < m_obstacles.size(); i++)
	{
		for (int j = 0; j < m_monsters->size(); j++)
		{
			Tile* obstacle = (m_obstacles)[i];
			CBoundingBox obstacleBounds = obstacle->GetBounds();

			Monster* monster = (*m_monsters)[j];
			CBoundingBox monsterBounds = monster->GetBounds();

			bool isColliding = CheckCollision(obstacleBounds, monsterBounds);
			bool wasColliding = ArrayContainsCollision(m_previousCollisions, obstacle, monster);

			if (isColliding)
			{
				AddCollision(obstacle, monster);

				if (wasColliding)
				{
					monster->OnObstacleCollisionEnter(obstacle);
				}
			}
		}
	}
}

void CollisionManager::BulletObstacle()
{
	//Checks if any bullets hit an obstacle
	std::vector<Tile*> m_obstacles = m_gameWorld->GetObstacles();

	for (int i = 0; i < m_obstacles.size(); i++)
	{
		for (int j = 0; j < monster_bullets->size(); j++)
		{
			Tile* obstacle = (m_obstacles)[i];
			CBoundingBox obstacleBounds = obstacle->GetBounds();

			Bullet* bullet = (*monster_bullets)[j];
			CBoundingBox bulletBounds = bullet->GetBounds();

			bool isColliding = CheckCollision(obstacleBounds, bulletBounds);
			bool wasColliding = ArrayContainsCollision(m_previousCollisions, obstacle, bullet);

			if (isColliding)
			{
				AddCollision(obstacle, bullet);

				if (!wasColliding)
				{
					std::cout << "bullet hit obstacle" << std::endl;
					bullet->setReuse();
				} 
			}
		}
	}
}