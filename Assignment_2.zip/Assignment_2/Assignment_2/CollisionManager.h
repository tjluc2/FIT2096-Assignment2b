#ifndef COLLISION_MANAGER_H
#define COLLISION_MANAGER_H

#include <vector>
#include "Collisions.h"
#include "Player.h"
#include "Monster.h"
#include "DynamicObject.h"
#include "Bullet.h"
#include "Tile.h"

#define MAX_ALLOWED_COLLISIONS 2048

class CollisionManager
{
private:
	Player* m_player;
	std::vector<Monster*>* m_monsters;
	std::vector<DynamicObject*>* m_health;
	std::vector<GameObject*>* m_walls;
	std::vector<Bullet*>* m_bullets;
	std::vector<Bullet*>* monster_bullets;
	std::vector<DynamicObject*>* m_ammoBlocks;
	GameWorld* m_gameWorld;
	
	int x, z;

	GameObject* m_currentCollisions[MAX_ALLOWED_COLLISIONS];

	// We need to know what objects were colliding last frame so we can determine if a collision has just begun or ended
	GameObject* m_previousCollisions[MAX_ALLOWED_COLLISIONS];

	int m_nextCurrentCollisionSlot;

	// Check if we already know about two objects colliding
	bool ArrayContainsCollision(GameObject* arrayToSearch[], GameObject* first, GameObject* second);

	// Register that a collision has occurred
	void AddCollision(GameObject* first, GameObject* second);

	void PlayerMonster();
	void PlayerHealth();
	void MonsterBullet();
	void PlayerBullet();
	void PlayerAmmo();
	void PlayerWall();
	void MonsterWall();
	void PlayerObstacle();
	void MonsterObstacle();
	void BulletObstacle();
public:
	CollisionManager(Player* player, std::vector<Monster*>* monsters, std::vector<DynamicObject*>* health, std::vector<Bullet*>* bullet,
		std::vector<Bullet*>* monsterBullets, std::vector<DynamicObject*>* ammoBlocks, GameWorld* gameWorld);
	void CheckCollisions();


};

#endif