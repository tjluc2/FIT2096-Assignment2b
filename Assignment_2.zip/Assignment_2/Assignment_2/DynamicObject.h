#ifndef DYNAMIC_OBJECT_H
#define DYNAMIC_OBJECT_H

#include "GameObject.h"
#include "Collisions.h"

class DynamicObject : public GameObject
{
private:
	int m_value;
	bool Used = false;
	CBoundingBox m_boundingBox;
public:
	DynamicObject();
	DynamicObject(Mesh* mesh, Shader* shader, Texture* texture, Vector3 position);
	~DynamicObject();

	void Update(float timestep);
	int GetValue() { return m_value;  }
	bool getUsed() { return Used; }					//Used to take item off map
	bool setUsed() { return Used = true; }
	CBoundingBox GetBounds() { return m_boundingBox; }

};


#endif