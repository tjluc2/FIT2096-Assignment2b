#include "FirstPerson.h"
#include "MathsHelper.h"
#include <iostream>

FirstPerson::FirstPerson(InputController* input, Player* player) {
	m_input = input;
	m_player = player;
	m_offset = Vector3(0.0f, 1.1f, 0.0f);			//Places camera where head of player is
	//m_offset = Vector3(0.0f, 5.0f, -5.0f);
	m_rotationSpeed = 1.0f;
	m_heightChangeSpeed = 10.0f;

	m_heading = 0.0f;		//Rotation around Y axis.
	m_pitch = 0.0f;			//Rotation around X axis.
}


void FirstPerson::Update(float timestep) {
	//Check mouse movement
	m_heading += m_input->GetMouseDeltaX() * m_rotationSpeed * timestep;
	m_pitch += m_input->GetMouseDeltaY() * m_rotationSpeed * timestep;

	//Limits how far the player can look up and down
	m_pitch = MathsHelper::Clamp(m_pitch, ToRadians(-60.0f), ToRadians(60.0f));

	//Performs X and Y rotations
	Matrix heading = Matrix::CreateRotationY(m_heading);
	Matrix pitch = Matrix::CreateRotationX(m_pitch);

	//Transforms from world space into local space
	Vector3 localRight = Vector3::TransformNormal(Vector3(1, 0, 0), heading);

	//Local forward vector parallel to the ground. Found by getting cross vector.
	Vector3 localForward = localRight.Cross(Vector3(0, 1, 0));
	
	//Gets current position of camera
	Vector3 cameraPos = m_offset + m_player->GetPosition();

	// Combine pitch and heading into one matrix for convenience
	Matrix lookAtRotation = pitch * heading;

	// Transform a world forward vector into local space (take pitch and heading into account)
	Vector3 lookAt = Vector3::TransformNormal(Vector3(0, 0, 1), lookAtRotation);

	//Add position to lookAt point to make it relative to our position instead of the origin
	lookAt += cameraPos;

	//Sets position of camera and where they should be looking.
	SetLookAt(lookAt);
	SetPosition(cameraPos);

	int bullets_left = m_player->GetBulletsLeft();
	if (m_input->GetKeyDown(VK_SPACE))			//Shoot bullet
	{
		if (bullets_left > 0)
		{
			m_player->shoot(localForward, m_heading);
		}
	}

	Camera::Update(timestep);
} 