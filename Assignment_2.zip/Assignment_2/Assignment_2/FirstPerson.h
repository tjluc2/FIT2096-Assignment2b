#ifndef FIRST_PERSON_H
#define FIRST_PERSON_H

#include "Camera.h"
#include "Player.h"
#include "InputController.h"

class FirstPerson : public Camera 
{
private: 
	InputController* m_input;
	Player* m_player;
	Vector3 m_offset;

	float m_moveSpeed;
	float m_rotationSpeed;
	float m_heightChangeSpeed;

	float m_heading;
	float m_pitch; 

public:
	FirstPerson(InputController* input, Player* player);

	void Update(float timestep);

};

#endif