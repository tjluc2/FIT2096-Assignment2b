/*	FIT2069 - Assignment
*	Game.cpp
*	Taylah Lucas - 26916525 - tjluc2
TO DO:
1. Lighting - make more colourful
2. Bullet Collisions with wall
*/


#include <iostream>
#include <sstream>
#include "Game.h"
#include "TexturedShader.h"
#include "DirectXTK/CommonStates.h"
#include "SurveillanceCamara.h"
#include "FirstPerson.h"
#include "CollisionManager.h"
#include <vector>



Game::Game()
{
	m_renderer = NULL;
	m_currentCam = NULL;
	m_input = NULL;
	m_meshManager = NULL;
	m_textureManager = NULL;
	m_diffuseTexturedShader = NULL;
	m_unlitTexturedShader = NULL;
	m_unlitVertexColouredShader = NULL;
	m_spriteBatch = NULL;
	m_arialFont18 = NULL;
	m_stateMachine = NULL;
	m_player = NULL;
	m_startButton = NULL;
	m_quitButton = NULL;
	m_audio = NULL;
}

Game::~Game() {}

bool Game::Initialise(Direct3D* renderer, AudioSystem* audio, InputController* input)
{
	m_renderer = renderer;
	m_input = input;
	m_audio = audio;
	m_meshManager = new MeshManager();
	m_textureManager = new TextureManager();

	if (!InitShaders())
		return false;

	if (!LoadMeshes())
		return false;

	if (!LoadTextures())
		return false;

	if (!LoadAudio())
		return false;

	LoadFonts();
	InitUI();
	InitGameWorld();			//Initialise game world
	InitStates();

	m_collisionManager = new CollisionManager(m_player, &m_monsters, &m_healthPacks, &m_bullets, &monster_bullets, &m_ammoBlocks, m_gameWorld);
	m_currentCam = new FirstPerson(m_input, m_player);
	//m_currentCam = new SurveillanceCamera(m_player, 0.5f);

}

bool Game::InitShaders()
{
	m_unlitVertexColouredShader = new Shader();
	if (!m_unlitVertexColouredShader->Initialise(m_renderer->GetDevice(), L"Assets/Shaders/VertexShader.vs", L"Assets/Shaders/VertexColourPixelShader.ps"))
		return false;
	
	m_unlitTexturedShader = new TexturedShader();
	if (!m_unlitTexturedShader->Initialise(m_renderer->GetDevice(), L"Assets/Shaders/VertexShader.vs", L"Assets/Shaders/TexturedPixelShader.ps"))
		return false;

	m_diffuseTexturedShader = new TexturedShader();
	if (!m_diffuseTexturedShader->Initialise(m_renderer->GetDevice(), L"Assets/Shaders/VertexShader.vs", L"Assets/Shaders/TexturedPixelShader.ps"))
		return false;

	return true;
}

bool Game::LoadMeshes()
{	
	//Load all meshes
	if (!m_meshManager->Load(m_renderer, "Assets/Meshes/ammoBlock.obj"))
		return false;

	if (!m_meshManager->Load(m_renderer, "Assets/Meshes/bullet.obj"))
		return false;

	if (!m_meshManager->Load(m_renderer, "Assets/Meshes/enemy.obj"))
		return false;

	if (!m_meshManager->Load(m_renderer, "Assets/Meshes/ground.obj"))
		return false;

	if (!m_meshManager->Load(m_renderer, "Assets/Meshes/player_capsule.obj"))
		return false;

	if (!m_meshManager->Load(m_renderer, "Assets/Meshes/ruby.obj"))
		return false;

	if (!m_meshManager->Load(m_renderer, "Assets/Meshes/wall_tile.obj"))
		return false;

	if (!m_meshManager->Load(m_renderer, "Assets/Meshes/progress_cube.obj"))
		return false;

	return true;
}

bool Game::LoadTextures()
{
	//Load all textures
	if (!m_textureManager->Load(m_renderer, "Assets/Textures/bullet.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/gradient_red.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/gradient_redDarker.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/gradient_redLighter.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/gradient_redPink.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/gradient_redOrange.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/green.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/ground.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/sprite_healthBar.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/sprite_hurtOverlay.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/tile_purple.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/target.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/button.png"))
		return false;


return true;
}

bool Game::LoadAudio()
{
	if (!m_audio->Load("Assets/Sounds/drumloop.wav"))
		return false;

	return true;
}

void Game::LoadFonts()
{
	m_arialFont18 = new SpriteFont(m_renderer->GetDevice(), L"Assets/Fonts/Arial-18pt.spritefont");
}

void Game::InitUI()
{
	m_spriteBatch = new SpriteBatch(m_renderer->GetDeviceContext());

	m_currentItemSprite = m_textureManager->GetTexture("Assets/Textures/sprite_healthBar.png");
	Texture* buttonTexture = m_textureManager->GetTexture("Assets/Textures/button.png");
	
	m_target = m_textureManager->GetTexture("Assets/Textures/target.png");

	// Also init any buttons here
	m_startButton = new Button(128, 64, buttonTexture, L"Start Game", Vector2(574, 385), m_spriteBatch, m_arialFont18, m_input, [this]
	{
		// Transition into the Gameplay state (these buttons are only used on the menu screen)
		m_stateMachine->ChangeState(GameStates::GAMEPLAY_STATE);
	});

	m_quitButton = new Button(128, 64, buttonTexture, L"Quit", Vector2(706, 385), m_spriteBatch, m_arialFont18, m_input, [this]
	{
		// Tell windows to send a WM_QUIT message into our message pump
		PostQuitMessage(0);
	});
}

void Game::InitStates()
{
	// Our state machine needs to know its owner (so it only runs the callbacks while its owner exists)
	m_stateMachine = new StateMachine<GameStates, Game>(this, GameStates::MENU_STATE);

	// Let's match some states with with their OnEnter, OnUpdate, OnRender, OnExit callbacks.
	// Have a look in StateMachine.h to see how this works internally.
	m_stateMachine->RegisterState(GameStates::MENU_STATE, &Game::Menu_OnEnter,
		&Game::Menu_OnUpdate, &Game::Menu_OnRender, &Game::Menu_OnExit);

	m_stateMachine->RegisterState(GameStates::GAMEPLAY_STATE, &Game::Gameplay_OnEnter,
		&Game::Gameplay_OnUpdate, &Game::Gameplay_OnRender, &Game::Gameplay_OnExit);

	m_stateMachine->RegisterState(GameStates::PAUSE_STATE, &Game::Pause_OnEnter,
		&Game::Pause_OnUpdate, &Game::Pause_OnRender, &Game::Pause_OnExit);
}

void Game::InitGameWorld()
{
	//Initialise game world
	m_gameWorld = new GameWorld(m_meshManager, m_diffuseTexturedShader, m_textureManager);			//Create game world

	float xSize = m_gameWorld->GetXSize();
	float zSize = m_gameWorld->GetZSize();

	//Initialise health packs
	int no_healthPacks = int(m_gameWorld->GetBoardSize() / 50);		//Returns initial number of health packs on board
	for (int i = 0; i < no_healthPacks; i++)
	{
		m_healthPacks.push_back(new DynamicObject(
			m_meshManager->GetMesh("Assets/Meshes/player_capsule.obj"),
			m_unlitTexturedShader,
			m_textureManager->GetTexture("Assets/Textures/green.png"),
			Vector3(m_gameWorld->RandXPos(), 0.1, m_gameWorld->RandZPos())));
		m_healthPacks[i]->SetUniformScale(0.5f);
		m_healthPacks[i]->SetZRotation(ToRadians(90.0f));
	}

	//Initialise ammo blocks
	int no_ammoBlocks = int(m_gameWorld->GetBoardSize() / 30);			//Initial number of ammo blocks on board
	for (int i = 0; i < no_ammoBlocks; i++)
	{
		m_ammoBlocks.push_back(new DynamicObject(
			m_meshManager->GetMesh("Assets/Meshes/ammoBlock.obj"),
			m_unlitTexturedShader,
			m_textureManager->GetTexture("Assets/Textures/bullet.png"),
			Vector3(m_gameWorld->RandXPos(), 0, m_gameWorld->RandZPos())));
	}

	//Initialize bullet objects for player
	for (int i = 0; i < 20; i++)
	{
		int damage = rand() % 2 + 1;				//Bullet does random amount of damage between 1 and 5 health.
		m_bullets.push_back(new Bullet(m_meshManager->GetMesh("Assets/Meshes/bullet.obj"),
			m_unlitTexturedShader,
			m_textureManager->GetTexture("Assets/Textures/bullet.png"),
			Vector3(0, -1, 0), damage, m_gameWorld));
	}

	//Initialize bullet object for monster
	for (int i = 0; i < 20; i++)
	{
		int damage = rand() % 2 + 1;				//Bullet does random amount of damage between 1 and 5 health.
		monster_bullets.push_back(new Bullet(m_meshManager->GetMesh("Assets/Meshes/bullet.obj"),
			m_unlitTexturedShader,
			m_textureManager->GetTexture("Assets/Textures/bullet.png"),
			Vector3(0, -1, 0), damage, m_gameWorld));
	}

	//Initialise player
	m_player = new Player(m_meshManager->GetMesh("Assets/Meshes/enemy.obj"),
		m_unlitTexturedShader,
		m_input,
		Vector3::Zero, m_bullets, m_audio);

	//Initialise monsters
	// Monster to run away from player
	m_monsters.push_back(new Monster(m_meshManager->GetMesh("Assets/Meshes/enemy.obj"),
		m_unlitTexturedShader,
		m_textureManager->GetTexture("Assets/Textures/gradient_redLighter.png"),
		Vector3(m_gameWorld->RandXPos(), 0, m_gameWorld->RandZPos()),
		m_player,
		2, 1, m_gameWorld, monster_bullets));
	m_monsters[0]->SetShootInterval(5000);					//Shoot player every 2 seconds

	//Enemy to move to random position on board
	m_monsters.push_back(new Monster(m_meshManager->GetMesh("Assets/Meshes/enemy.obj"),
		m_unlitTexturedShader,
		m_textureManager->GetTexture("Assets/Textures/gradient_red.png"),
		Vector3(m_gameWorld->RandXPos(), 0, m_gameWorld->RandZPos()),
		m_player,
		4, 2, m_gameWorld, monster_bullets));			
	m_monsters[1]->SetShootInterval(6000);

	//Enemy to chase player
	m_monsters.push_back(new Monster(m_meshManager->GetMesh("Assets/Meshes/enemy.obj"),
		m_unlitTexturedShader,
		m_textureManager->GetTexture("Assets/Textures/gradient_redPink.png"),
		Vector3(m_gameWorld->RandXPos(), 0, m_gameWorld->RandZPos()),
		m_player,
		6, 3, m_gameWorld, monster_bullets));
	m_monsters[2]->SetShootInterval(7500);

	//Enemy to run to a spot in front of player
	m_monsters.push_back(new Monster(m_meshManager->GetMesh("Assets/Meshes/enemy.obj"),					
		m_unlitTexturedShader,
		m_textureManager->GetTexture("Assets/Textures/gradient_redOrange.png"),
		Vector3(m_gameWorld->RandXPos(), 0, m_gameWorld->RandZPos()),
		m_player,
		8, 4, m_gameWorld, monster_bullets));
	m_monsters[3]->SetShootInterval(8000);

	//Enemy to bail to a random spot when the player is too close
	m_monsters.push_back(new Monster(m_meshManager->GetMesh("Assets/Meshes/enemy.obj"),
		m_unlitTexturedShader,
		m_textureManager->GetTexture("Assets/Textures/gradient_redDarker.png"),
		Vector3(m_gameWorld->RandXPos(), 0, m_gameWorld->RandZPos()),
		m_player,
		10, 5, m_gameWorld, monster_bullets));
	m_monsters[4]->SetShootInterval(10000);

	for (int i = 0; i < m_monsters.size(); i++)
	{
		monster_health.push_back(new DynamicObject(m_meshManager->GetMesh("Assets/Meshes/progress_cube.obj"),
			m_unlitTexturedShader,
			m_textureManager->GetTexture("Assets/Textures/sprite_healthBar.png"),
			m_monsters[i]->GetPosition() + Vector3(0, 1, 0)));
	}
}


void Game::Update(float timestep)
{
	m_input->BeginUpdate();

	m_audio->Update();
	
	m_stateMachine->Update(timestep);
	/*
	if (m_player->GetHealth() <= 0) 	//Checks if player dies
	{
		int m_playerXP = m_player->GetReward();
		int m_defeated = m_player->GetDefeated();
		char text[128];
		sprintf_s(text, "Player XP: %d \n Monsters Defeated: %d", m_playerXP, m_defeated);
		MessageBox(NULL, text, "GAME OVER", MB_OK);
		PostQuitMessage(0);
		Shutdown();
		exit(0);
	}
	*/

	m_input->EndUpdate();

}

void Game::Render()
{
	m_renderer->BeginScene(0.2f, 0.2f, 0.2f, 1.0f);

	m_stateMachine->Render();

	m_renderer->EndScene();		
}

void Game::Menu_OnEnter()
{
	OutputDebugString("Menu OnEnter\n");
}

void Game::Menu_OnUpdate(float timestep)
{
	// Button's need to update so they can check if the mouse is over them (they swap to a hover section of the image)
	m_startButton->Update();
	m_quitButton->Update();
}

void Game::Menu_OnRender()
{
	DrawMenuUI();
}

void Game::Menu_OnExit()
{
	OutputDebugString("Menu OnExit\n");
}

void Game::Gameplay_OnEnter()
{
	OutputDebugString("GamePlay OnEnter\n");
}

void Game::Gameplay_OnUpdate(float timestep)
{
	// Update all our gameobjects
	m_gameWorld->Update(timestep);
	m_player->Update(timestep);

	for (int i = 0; i < m_bullets.size(); i++)
	{
		m_bullets[i]->Update(timestep);
		monster_bullets[i]->Update(timestep);
	}

	for (int i = 0; i < m_healthPacks.size(); i++)
	{
		m_healthPacks[i]->Update(timestep);
	}

	for (int i = 0; i < m_ammoBlocks.size(); i++)
	{
		m_ammoBlocks[i]->Update(timestep);
	}

	for (int i = 0; i < m_monsters.size(); i++)
	{
		m_monsters[i]->Update(timestep);
		//Monster health bar to rescale when monter is hit and follow monster around
		monster_health[i]->SetXScale(m_monsters[i]->getHealth() * 0.1);
		monster_health[i]->SetYRotation(m_monsters[i]->GetYRotation());
		monster_health[i]->SetPosition(m_monsters[i]->GetPosition() + Vector3(0, 1, 0));
		monster_health[i]->Update(timestep);
	}

	// Only interested in collisions during the gameplay state
	m_collisionManager->CheckCollisions();

	m_currentCam->Update(timestep);

	// Set audio listener after the camera has updated so its data is valid on the first frame
	m_audio->SetListener3DAttributes(m_currentCam->GetPosition(), m_currentCam->GetForward(), m_currentCam->GetUp(), m_currentCam->GetVelocity());

	// Should we pause
	if (m_input->GetKeyDown('P'))
	{
		m_stateMachine->ChangeState(GameStates::PAUSE_STATE);
	}
}

void Game::Gameplay_OnRender()
{
	m_gameWorld->Render(m_renderer, m_currentCam);
	
	// Draw our gameobjects
	for (int i = 0; i < m_healthPacks.size(); i++)
	{
		if (m_healthPacks[i]->getUsed() == false)
		{
			m_healthPacks[i]->Render(m_renderer, m_currentCam);
		}
	}

	for (int i = 0; i < m_ammoBlocks.size(); i++)
	{
		if (m_ammoBlocks[i]->getUsed() == false) {
			m_ammoBlocks[i]->Render(m_renderer, m_currentCam);
		}
	}

	for (int i = 0; i < m_bullets.size(); i++)
	{
		m_bullets[i]->Render(m_renderer, m_currentCam);
		monster_bullets[i]->Render(m_renderer, m_currentCam);
	}

	for (int i = 0; i < m_monsters.size(); i++)
	{
		if (m_monsters[i]->getHealth() > 0) {
			m_monsters[i]->Render(m_renderer, m_currentCam);
			monster_health[i]->Render(m_renderer, m_currentCam);
		}
	}

	DrawGameUI();
}

void Game::Gameplay_OnExit()
{
	OutputDebugString("GamePlay OnExit\n");
}

void Game::Pause_OnEnter()
{
	OutputDebugString("Pause OnEnter\n");
}

void Game::Pause_OnUpdate(float timestep)
{
	// Check if we should exit pause
	if (m_input->GetKeyDown('P'))
	{
		m_stateMachine->ChangeState(GameStates::GAMEPLAY_STATE);
	}
}

void Game::Pause_OnRender()
{
	// Keep drawing the game when paused (it's not being updated though which is what freezes it)
	Gameplay_OnRender();

	// In addition to the game, draw some UI to say we're paused
	DrawPauseUI();
}

void Game::Pause_OnExit()
{
	OutputDebugString("Pause OnExit\n");
}

void Game::DrawMenuUI()
{
	BeginUI();

	m_startButton->Render();
	m_quitButton->Render();

	m_arialFont18->DrawString(m_spriteBatch, L"FIT2096 Assignment 2", Vector2(545, 295), Color(0.0f, 0.0f, 0.0f), 0, Vector2(0, 0));

	EndUI();
}

void Game::DrawGameUI()
{
	BeginUI();

	//m_gameWorld->Render(m_renderer, m_currentCam);

	m_arialFont18->DrawString(m_spriteBatch, L"P to toggle pause", Vector2(550, 40), Color(0.0f, 0.0f, 0.0f), 0, Vector2(0, 0));
	
	if (m_player) {
		std::wstringstream dd;					//Displays current score of player
		float m_playerScore = m_player->GetReward();
		dd << "Score: " << m_playerScore;
		m_playerScoreText = dd.str();

		std::wstringstream ss;					//Displays amount of bullets player has left
		float m_bulletsLeft = m_player->GetBulletsLeft();
		ss << "Bullets Left: " << m_bulletsLeft;
		m_bulletsLeftText = ss.str();
	} 

	m_arialFont18->DrawString(m_spriteBatch, m_playerScoreText.c_str(), Vector2(20, 150), Color(1.0f, 1.0f, 1.0f), 0, Vector2(0, 0));
	m_arialFont18->DrawString(m_spriteBatch, m_bulletsLeftText.c_str(), Vector2(20, 180), Color(1.0f, 1.0f, 1.0f), 0, Vector2(0, 0));

	int x = 550;
	for (int i = 0; i < m_player->GetHealth(); i++) {
		m_spriteBatch->Draw(m_currentItemSprite->GetShaderResourceView(), Vector2(x, 680), Color(1.0f, 1.0f, 1.0f));
		x += 30;
	}
	m_spriteBatch->Draw(m_target->GetShaderResourceView(), Vector2(625, 360), Color(1.0f, 1.0f, 1.0f));

	EndUI();
}

void Game::DrawPauseUI()
{
	BeginUI();
	m_arialFont18->DrawString(m_spriteBatch, L"Paused", Vector2(605, 10), Color(0.0f, 0.0f, 0.0f), 0, Vector2(0, 0));
	EndUI();
}

void Game::BeginUI()
{
	// Sprites don't use a shader 
	m_renderer->SetCurrentShader(NULL);

	CommonStates states(m_renderer->GetDevice());
	m_spriteBatch->Begin(SpriteSortMode_Deferred, states.NonPremultiplied());
}

void Game::EndUI()
{
	m_spriteBatch->End();
}

void Game::Shutdown()
{	
	if (m_gameWorld)
	{
		delete (m_gameWorld);
	}

	if (m_player) {
		delete (m_player);
	}

	if (m_currentCam)
	{
		delete m_currentCam;
		m_currentCam = NULL;
	}

	for (int i = 0; i < m_monsters.size(); i++)
	{
		delete(m_monsters[i]);
	}

	for (int i = 0; i < m_bullets.size(); i++)
	{
		delete(m_bullets[i]);
	}

	for (int i = 0; i < monster_bullets.size(); i++)
	{
		delete(monster_bullets[i]);
	}
	
	for (int i = 0; i < monster_health.size(); i++)
	{
		delete(monster_health[i]);
	}
	
	if (m_unlitVertexColouredShader)
	{
		m_unlitVertexColouredShader->Release();
		delete m_unlitVertexColouredShader;
		m_unlitVertexColouredShader = NULL;
	}

	if (m_meshManager)
	{
		m_meshManager->Release();
		delete m_meshManager;
		m_meshManager = NULL;
	}

	if (m_textureManager)
	{
		m_textureManager->Release();
		delete m_textureManager;
		m_textureManager = NULL;
	}

	if (m_spriteBatch)
	{
		delete m_spriteBatch;
		m_spriteBatch = NULL;
	}

	if (m_arialFont18)
	{
		delete m_arialFont18;
		m_arialFont18 = NULL;
	}

	if (m_audio)
	{
		m_audio->Shutdown();
		delete m_audio;
		m_audio = NULL;
	}
} 