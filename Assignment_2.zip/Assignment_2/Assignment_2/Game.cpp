/*	FIT2069 - Assignment
*	Game.cpp
*	Taylah Lucas - 26916525 - tjluc2
*/

#include <iostream>
#include <sstream>
#include "Game.h"
#include "TexturedShader.h"
#include "DirectXTK/CommonStates.h"
#include "SurveillanceCamara.h"
#include "FirstPerson.h"



Game::Game()
{
	m_renderer = NULL;
	m_currentCam = NULL;
	m_input = NULL;
	m_meshManager = NULL;
	m_textureManager = NULL;
	m_unlitTexturedShader = NULL;
	m_unlitVertexColouredShader = NULL;
	m_spriteBatch = NULL;
	m_arialFont18 = NULL;
}

Game::~Game() {}

bool Game::Initialise(Direct3D* renderer, InputController* input)
{
	m_renderer = renderer;
	m_input = input;
	m_meshManager = new MeshManager();
	m_textureManager = new TextureManager();

	//If none are loaded correctly they will return false.
	if (!InitShaders())
		return false;

	if (!LoadMeshes())
		return false;

	if (!LoadTextures())
		return false;

	//Initialises player
	m_player.push_back(new Player(
		m_meshManager->GetMesh("Assets/Meshes/enemy.obj"),
		m_unlitTexturedShader,
		m_input,
		m_textureManager->GetTexture("Assets/Textures/tile_blue.png"),
		Vector3::Zero));

	LoadFonts();
	InitUI();
	InitGameWorld();			//Initialise game world

	int i = 0;
	//Level 1 monster
	m_monsters.push_back(new Monster(
		m_meshManager->GetMesh("Assets/Meshes/enemy.obj"),
		m_unlitTexturedShader,
		m_input,
		Vector3(redTiles[i].first, 0, redTiles[i].second),
		m_textureManager->GetTexture("Assets/Textures/gradient_redLighter.png"),
		2, 1));
	i += 1;
	//Level 2 monster
	m_monsters.push_back(new Monster(
		m_meshManager->GetMesh("Assets/Meshes/enemy.obj"),
		m_unlitTexturedShader,
		m_input,
		Vector3(redTiles[i].first, 0, redTiles[i].second),
		m_textureManager->GetTexture("Assets/Textures/gradient_red.png"),
		4, 2));
	i += 1;
	//Level 3 monster
	m_monsters.push_back(new Monster(
		m_meshManager->GetMesh("Assets/Meshes/enemy.obj"),
		m_unlitTexturedShader,
		m_input,
		Vector3(redTiles[i].first, 0, redTiles[i].second),
		m_textureManager->GetTexture("Assets/Textures/gradient_redPink.png"),
		6, 3));
	i += 1;
	//Level 4 monster
	m_monsters.push_back(new Monster(
		m_meshManager->GetMesh("Assets/Meshes/enemy.obj"),
		m_unlitTexturedShader,
		m_input,
		Vector3(redTiles[i].first, 0, redTiles[i].second),
		m_textureManager->GetTexture("Assets/Textures/gradient_redOrange.png"),
		8, 4));
	i += 1;
	//Level 5 monster
	m_monsters.push_back(new Monster(
		m_meshManager->GetMesh("Assets/Meshes/enemy.obj"),
		m_unlitTexturedShader,
		m_input,
		Vector3(redTiles[i].first, 0, redTiles[i].second),
		m_textureManager->GetTexture("Assets/Textures/gradient_redDarker.png"),
		10, 5));

	m_currentCam = new FirstPerson(m_input, m_player[0]);
	//m_currentCam = new SurveillanceCamera(m_player[0], 0.5f);

	for (int i = 0; i < m_monsters.size(); i++) {			//Initialise monsters to face player
		m_monsters[i]->InitRotation(m_monsters[i]->GetPosition(), i);
	}
	return true;
}

bool Game::InitShaders()
{
	m_unlitVertexColouredShader = new Shader();
	if (!m_unlitVertexColouredShader->Initialise(m_renderer->GetDevice(), L"Assets/Shaders/VertexShader.vs", L"Assets/Shaders/VertexColourPixelShader.ps"))
		return false;
	
	m_unlitTexturedShader = new TexturedShader();
	if (!m_unlitTexturedShader->Initialise(m_renderer->GetDevice(), L"Assets/Shaders/VertexShader.vs", L"Assets/Shaders/TexturedPixelShader.ps"))
		return false;

	return true;
}

bool Game::LoadMeshes()
{	
	if (!m_meshManager->Load(m_renderer, "Assets/Meshes/player_capsule.obj"))
		return false;

	if (!m_meshManager->Load(m_renderer, "Assets/Meshes/floor_tile.obj"))
		return false;

	if (!m_meshManager->Load(m_renderer, "Assets/Meshes/wall_tile.obj"))
		return false;

	//Assignment 2 meshes
	if (!m_meshManager->Load(m_renderer, "Assets/Meshes/enemy.obj"))
		return false;

	return true;
}

bool Game::LoadTextures()
{
	//Load all textures
	if (!m_textureManager->Load(m_renderer, "Assets/Textures/tile_blue.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/tile_purple.png"))
		return false;

	//Assignment 2 textures 
	if (!m_textureManager->Load(m_renderer, "Assets/Textures/ground.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/disabled.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/sprite_healthBar.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/green.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/gradient_red.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/gradient_redDarker.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/gradient_redLighter.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/gradient_redPink.png"))
		return false;

	if (!m_textureManager->Load(m_renderer, "Assets/Textures/gradient_redOrange.png"))
		return false;

return true;
}

void Game::LoadFonts()
{
	m_arialFont18 = new SpriteFont(m_renderer->GetDevice(), L"Assets/Fonts/Arial-18pt.spritefont");
}

void Game::InitUI()
{
	m_spriteBatch = new SpriteBatch(m_renderer->GetDeviceContext());
	m_currentItemSprite = m_textureManager->GetTexture("Assets/Textures/sprite_healthBar.png");
}

void Game::RefreshUI()
{
	if (m_player[0]) {
		std::wstringstream dd;
		float m_playerScore = m_player[0]->GetReward();
		dd << "Score: " << m_playerScore;
		m_playerScoreText = dd.str();
	}
}

void Game::InitGameWorld()
{
	//Creates a vector array containing unfilled coordinates of map
	std::vector<std::pair<int, int>> xyPos;

	for (int i = 0; i < x; i++) {
		for (int j = 0; j < z; j++) {		
			xyPos.push_back(std::pair<int, int>(i, j));		//Stores unfilled coordinate pairs
		}
	}


	int allTiles[5] = { green, blue, disabled, 5 };			//Array of remaining tiles left for each color {green, blue, disabled, red}
	int remainCoord = xyPos.size();		

	for (int i = 0; i < sizeof(allTiles) / sizeof(*allTiles); i++) {		
		int amount = allTiles[i];				//Amount of each tile to be put onto map
		for (int j = 0; j < amount; j++) {
			bool validPos = false;
			int randPos = (rand() % remainCoord);			//Calculates random position

			//Ensures players starting position is not surrounded by disabled tiles, and they do not start on a coloured tile
			while (validPos == false) {
				if (xyPos[randPos].first == 0 && xyPos[randPos].second == 0) {
					randPos = (rand() % remainCoord);		
				}
				else if (xyPos[randPos].first == 0 && xyPos[randPos].second == 1) {
					randPos = (rand() % remainCoord);	
				}
				else if (xyPos[randPos].first == 1 && xyPos[randPos].second == 0) {
					randPos = (rand() % remainCoord);
				}
				else {
					validPos = true;
				}
			}

			switch (i) {
			case 0:			//Add green tile
				greenTiles.push_back(std::pair<int, int>(xyPos[randPos].first, xyPos[randPos].second));
				m_tiles.push_back(new Tile(
					m_meshManager->GetMesh("Assets/Meshes/floor_tile.obj"),
					m_unlitTexturedShader,
					m_input,
					Vector3(xyPos[randPos].first, 0, xyPos[randPos].second),
					m_textureManager->GetTexture("Assets/Textures/ground.png")));
				break;
			case 1:				//Add blue tile
				blueTiles.push_back(std::pair<int, int>(xyPos[randPos].first, xyPos[randPos].second));
				m_tiles.push_back(new Tile(
					m_meshManager->GetMesh("Assets/Meshes/floor_tile.obj"),
					m_unlitTexturedShader,
					m_input,
					Vector3(xyPos[randPos].first, 0, xyPos[randPos].second),
					m_textureManager->GetTexture("Assets/Textures/tile_blue.png")));
				break;
			case 2:			//Add disabled tile
				disabledTiles.push_back(std::pair<int, int>(xyPos[randPos].first, xyPos[randPos].second));
				m_tiles.push_back(new Tile(
					m_meshManager->GetMesh("Assets/Meshes/floor_tile.obj"),
					m_unlitTexturedShader,
					m_input,
					Vector3(xyPos[randPos].first, 0, xyPos[randPos].second),
					m_textureManager->GetTexture("Assets/Textures/disabled.png")));
				break;
			case 3:		//Add red tile
				redTiles.push_back(std::pair<int, int>(xyPos[randPos].first, xyPos[randPos].second));
				m_tiles.push_back(new Tile(
					m_meshManager->GetMesh("Assets/Meshes/floor_tile.obj"),
					m_unlitTexturedShader,
					m_input,
					Vector3(xyPos[randPos].first, 0, xyPos[randPos].second),
					m_textureManager->GetTexture("Assets/Textures/ground.png")));
				break;
			}
			xyPos.erase(xyPos.begin() + randPos);		//Removed filled coordinate from vector array
			remainCoord -= 1;
		}
	}

	//Sets remaining tiles to walkable white tiles
	for (int i = 0; i < remainCoord; i++) {
		m_tiles.push_back(new Tile(
			m_meshManager->GetMesh("Assets/Meshes/floor_tile.obj"),
			m_unlitTexturedShader,
			m_input,
			Vector3(xyPos[i].first, 0, xyPos[i].second),
			m_textureManager->GetTexture("Assets/Textures/ground.png")));
	}

	for (int i = -1; i < z + 1; i++) {
		//Left wall
		m_tiles.push_back(new Tile(
		m_meshManager->GetMesh("Assets/Meshes/wall_tile.obj"),
		m_unlitTexturedShader,
		m_input,
		Vector3(-1, 0, i),
		m_textureManager->GetTexture("Assets/Textures/tile_purple.png")));

		//Right wall
		m_tiles.push_back(new Tile(
			m_meshManager->GetMesh("Assets/Meshes/wall_tile.obj"),
			m_unlitTexturedShader,
			m_input,
			Vector3(x, 0, i),
			m_textureManager->GetTexture("Assets/Textures/tile_purple.png")));
	} 

	for (int i = 0; i < x; i++) {
		//Back wall
		m_tiles.push_back(new Tile(
			m_meshManager->GetMesh("Assets/Meshes/wall_tile.obj"),
			m_unlitTexturedShader,
			m_input,
			Vector3(i, 0, z),
			m_textureManager->GetTexture("Assets/Textures/tile_purple.png")));

		//Front wall
		m_tiles.push_back(new Tile(
			m_meshManager->GetMesh("Assets/Meshes/wall_tile.obj"),
			m_unlitTexturedShader,
			m_input,
			Vector3(i, 0, -1),
			m_textureManager->GetTexture("Assets/Textures/tile_purple.png"))); 
	}

	//Creates green health capsules
	for (int i = 0; i < greenTiles.size(); i++) {
		m_tileObject.push_back(new GameObject(
			m_meshManager->GetMesh("Assets/Meshes/player_capsule.obj"),
			m_unlitTexturedShader,
			Vector3(greenTiles[i].first, 0, greenTiles[i].second),
			m_textureManager->GetTexture("Assets/Textures/green.png")));
	}

	for (int i = 0; i < m_monsters.size(); i++) {
		m_monsters[i]->InitRotation(m_monsters[i]->GetPosition(), i);
	}
}

void Game::Update(float timestep)
{
	m_input->BeginUpdate();
	
	Vector3 prevPos = m_player[0]->GetPosition();			//Gets previous position of player	
	m_player[0]->movePlayer(x, z, disabledTiles);		//Moves player to next position

	Vector3 currPos = m_player[0]->GetPosition();				//Gets current position of player

	if (m_player[0]->checkEnd(disabledTiles, x, z) == false) {		//Checks that player canmove (if not, game is over)
		int m_playerXP = m_player[0]->GetReward();
		int m_defeated = m_player[0]->GetDefeated();
		char text[128];
		sprintf_s(text, "Player XP: %d \n Monsters Defeated: %d", m_playerXP, m_defeated);
		MessageBox(NULL, text, "GAME OVER", MB_OK);
		PostQuitMessage(0);
		Shutdown();
	}

	if (currPos != prevPos) {			//Detects if player has moved				
		for (int i = 0; i < m_monsters.size(); i++) {				//Rotate enemies to face player
			m_monsters[i]->SetRotation(currPos, m_monsters[i]->GetPosition(), prevPos, i);
		}
		for (int i = 0; i < allTiles; i++) {						//Changes previous tile to disabled tile
			Vector3 currTiles = m_tiles[i]->GetPosition();
			if ((prevPos.x == int(currTiles.x)) && (prevPos.z == int(currTiles.z))) {
				m_tiles[i]->SetTexture(m_textureManager->GetTexture("Assets/Textures/disabled.png"));	//Sets tile to disabled grey
				disabledTiles.push_back(std::pair<int, int>(int(currTiles.x), int(currTiles.z)));
			}
		} 

		//Checks if player lands on green tile 
		for (int i = 0; i < m_tileObject.size(); i++) {
			Vector3 greenTile = m_tileObject[i]->GetPosition();
			if ((greenTile.x == currPos.x) && (greenTile.z == currPos.z)) {
				m_player[0]->increaseHealth();
				m_tileObject.erase(m_tileObject.begin() + i);
				break;
			}
		}

		//Checks if player lands on blue tile -- CHECK THIS ALL
		for (int i = 0; i < blueTiles.size(); i++) {
			if ((blueTiles[i].first == currPos.x) && (blueTiles[i].second == currPos.z)) {			//If player lands on blue tile
				for (int j = 0; j < allTiles; j++) {
					Vector3 currBlue = m_tiles[j]->GetPosition();					
					if ((blueTiles[i].first == currBlue.x) && (blueTiles[i].second == currBlue.z)) {		//Disables first blue tile
						m_tiles[j]->SetTexture(m_textureManager->GetTexture("Assets/Textures/disabled.png"));
						disabledTiles.push_back(std::pair<int, int>(currBlue.x, currBlue.z));
					}
				}
				blueTiles.erase(blueTiles.begin() + i);			//Delete current blue tile from list of remaining blue tiles.
				m_player[0]->transportPlayer(blueTiles);
				Vector3 newPos = m_player[0]->GetPosition();
				for (int k = 0; k < blueTiles.size(); k++) {
					if ((blueTiles[k].first == newPos.x) && (blueTiles[k].second == newPos.z)) {
						blueTiles.erase(blueTiles.begin() + k);
					}
				}
				break;
			}
		}

		//Checks if player lands on red tile
		for (int i = 0; i < m_monsters.size(); i++) {
			Vector3 redTile = m_monsters[i]->GetPosition();
			if ((redTile.x == currPos.x) && (redTile.z == currPos.z)) {
				int currHealth = m_player[0]->monsterBattle(m_monsters[i]);
				if (currHealth <= 0) {							//If player dies, end of game message displayed
					int m_playerXP = m_player[0]->GetReward();
					int m_defeated = m_player[0]->GetDefeated();
					char text[128];
					sprintf_s(text, "Player XP: %d \n Monsters Defeated: %d", m_playerXP, m_defeated);
					MessageBox(NULL, text, "GAME OVER", MB_OK);
					PostQuitMessage(0);

				} 
				else {
					float xScale = m_monsters[i]->GetDamage() * 0.1;
					m_monsters.erase(m_monsters.begin() + i);
				}
				break;
			}
		}
	}

	RefreshUI();
	
	m_currentCam->Update(timestep);

	m_input->EndUpdate();
}

void Game::Render()
{
	m_renderer->BeginScene(0.2f, 0.2f, 0.2f, 1.0f);

	//Render tile objects
	for (int i = 0; i < m_tiles.size(); i++) {
		m_tiles[i]->Render(m_renderer, m_currentCam);
	}

	//Render player objects
	for (int i = 0; i < m_player.size(); i++) {
		m_player[i]->Render(m_renderer, m_currentCam);
	}

	//Render monster objects
	for (int i = 0; i < m_monsters.size(); i++) {
		m_monsters[i]->Render(m_renderer, m_currentCam);
	}

	//Render objects to go on tiles
	for (int i = 0; i < m_tileObject.size(); i++) {
		m_tileObject[i]->Render(m_renderer, m_currentCam);
	}

	DrawUI();

	m_renderer->EndScene();		
}

void Game::DrawUI()
{
	m_renderer->SetCurrentShader(NULL);

	CommonStates states(m_renderer->GetDevice());
	m_spriteBatch->Begin(SpriteSortMode_Deferred, states.NonPremultiplied());

	m_arialFont18->DrawString(m_spriteBatch, m_playerScoreText.c_str(), Vector2(20, 150), Color(1.0f, 1.0f, 1.0f), 0, Vector2(0, 0));

	int x = 550;
	for (int i = 0; i < m_player[0]->getHealth(); i++) {
		m_spriteBatch->Draw(m_currentItemSprite->GetShaderResourceView(), Vector2(x, 680), Color(1.0f, 1.0f, 1.0f));
		x += 30;
	}
	m_spriteBatch->End();
}

void Game::Shutdown()
{	
	//Delete all game objects
	for (unsigned int i = 0; i < m_tiles.size(); i++) {
		delete m_tiles[i];
	}

	for (unsigned int i = 0; i < m_player.size(); i++) {
		delete m_player[i];
	}

	for (unsigned int i = 0; i < m_monsters.size(); i++) {
		delete m_monsters[i];
	}

	for (unsigned int i = 0; i < m_tileObject.size(); i++) {
		delete m_tileObject[i];
	}
	

	if (m_currentCam)
	{
		delete m_currentCam;
		m_currentCam = NULL;
	}

	if (m_unlitVertexColouredShader)
	{
		m_unlitVertexColouredShader->Release();
		delete m_unlitVertexColouredShader;
		m_unlitVertexColouredShader = NULL;
	}

	if (m_meshManager)
	{
		m_meshManager->Release();
		delete m_meshManager;
		m_meshManager = NULL;
	}

	if (m_textureManager)
	{
		m_textureManager->Release();
		delete m_textureManager;
		m_textureManager = NULL;
	}

	if (m_spriteBatch)
	{
		delete m_spriteBatch;
		m_spriteBatch = NULL;
	}

	if (m_arialFont18)
	{
		delete m_arialFont18;
		m_arialFont18 = NULL;
	}
} 