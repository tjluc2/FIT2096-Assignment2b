/*	FIT2069 - Assignment 1
*	Game.h
*	Taylah Lucas - 26916525 - tjluc2
*/

#ifndef GAME_H
#define GAME_H

#include "Direct3D.h"
#include "Camera.h"
#include "InputController.h"
#include "MeshManager.h"
#include "TextureManager.h"
#include "GameObject.h"
#include "Tile.h"
#include "Player.h"
#include "Monster.h"

#include "DirectXTK/SpriteBatch.h"
#include "DirectXTK/SpriteFont.h"

#include <vector>

class Game
{
private:
	Camera* m_currentCam;		
	Direct3D* m_renderer;
	InputController* m_input;
	MeshManager* m_meshManager;
	TextureManager* m_textureManager;

	Shader* m_unlitVertexColouredShader;
	Shader* m_unlitTexturedShader;

	std::vector<GameObject*> m_tileObject;		//Objects to sit on tiles
	std::vector<Player*> m_player;		//Player and health capsule
	std::vector<Tile*> m_tiles;		//Collection of tiles
	std::vector<Monster*> m_monsters;		//Monsters

	int x = 20;			//X size of map		- These can be altered to any size
	int z = 10;			//Z size of map 

	//Calculate tile amounts	- Calculation dependent on size of map (x and z values)
	int green = 0.09 * (x*z);
	int blue = 0.08 * (x*z);
	int disabled = 0.12 * (x*z);
	int allTiles = x*z;

	//Vector array for filled tile coordinates of each type
	std::vector<std::pair<int, int>> greenTiles;
	std::vector<std::pair<int, int>> blueTiles;
	std::vector<std::pair<int, int>> disabledTiles;
	std::vector<std::pair<int, int>> redTiles;

	// Splitting initialisation up into several steps
	bool InitShaders();
	bool LoadMeshes();
	bool LoadTextures();
	void InitGameWorld();

	//Load font/Sprite batch
	SpriteBatch* m_spriteBatch;
	SpriteFont* m_arialFont18;

	std::wstring m_playerScoreText;

	Texture* m_currentItemSprite;

	void LoadFonts();
	void InitUI();
	void DrawUI();
	void RefreshUI();

	

public:
	Game();	
	~Game();

	bool Initialise(Direct3D* renderer, InputController* input); //The initialise method will load all of the content for the game (meshes, textures, etc.)

	void Update(float timestep);	//The overall Update method for the game. All gameplay logic will be done somewhere within this method
	void Render();					//The overall Render method for the game. Here all of the meshes that need to be drawn will be drawn

	void Shutdown(); //Cleanup everything we initialised
};

#endif