/*	FIT2069 - Assignment 1
*	Game.h
*	Taylah Lucas - 26916525 - tjluc2
*/

#ifndef GAME_H
#define GAME_H

#include "Direct3D.h"
#include "Camera.h"
#include "InputController.h"
#include "MeshManager.h"
#include "TextureManager.h"
#include "GameWorld.h"
#include "GameObject.h"
#include "Player.h"
#include "Monster.h"
#include "DynamicObject.h"
#include "CollisionManager.h"	
#include "Bullet.h"
#include "StateMachine.h"
#include "Button.h"
#include "AudioSystem.h"

#include "DirectXTK/SpriteBatch.h"
#include "DirectXTK/SpriteFont.h"

#include <vector>

class Game
{
private:
	Camera* m_currentCam;		
	Direct3D* m_renderer;
	InputController* m_input;
	MeshManager* m_meshManager;
	TextureManager* m_textureManager;
	CollisionManager* m_collisionManager;
	AudioSystem* m_audio;

	enum class GameStates
	{
		MENU_STATE,
		GAMEPLAY_STATE,
		PAUSE_STATE,
		STATE_COUNT
	};

	StateMachine<GameStates, Game>* m_stateMachine;

	//Shaders
	Shader* m_unlitVertexColouredShader;
	Shader* m_unlitTexturedShader;
	Shader* m_diffuseTexturedShader;
	Shader* m_diffuseTexturedFogShader;

	GameWorld* m_gameWorld;				//Represents the game world
	Player* m_player;				//Represents the player
	std::vector<Monster*> m_monsters;			//Vector array of monsters
	std::vector<DynamicObject*> m_healthPacks;		//Vector array of health packs
	std::vector<DynamicObject*> m_ammoBlocks;			//Vector array of ammo blocks
	std::vector<Bullet*> m_bullets;				//Vector array of bullets
	std::vector<Bullet*> monster_bullets;			//Vector array of bullets that monsters can use
	std::vector<DynamicObject*> monster_health;		//Vector array of health bars to go above enemy
		
	int no_healthPacks;

	// Splitting initialisation up into several steps
	bool InitShaders();
	bool LoadMeshes();
	bool LoadTextures();
	void InitGameWorld();
	void InitStates();
	void LoadFonts();
	bool LoadAudio();

	// Our menu screen will have a "start" and "quit" button
	Button* m_startButton;
	Button* m_quitButton;

	//Load font/Sprite batch
	SpriteBatch* m_spriteBatch;
	SpriteFont* m_arialFont18;

	std::wstring m_playerScoreText;
	std::wstring m_bulletsLeftText;

	Texture* m_currentItemSprite;
	Texture* m_target;

	//UI 
	void InitUI();
	void DrawMenuUI();
	void DrawGameUI();
	void DrawPauseUI();
	void BeginUI();
	void EndUI();

	//For State Machine
	void Menu_OnEnter();
	void Menu_OnUpdate(float timestep);
	void Menu_OnRender();
	void Menu_OnExit();

	void Gameplay_OnEnter();
	void Gameplay_OnUpdate(float timestep);
	void Gameplay_OnRender();
	void Gameplay_OnExit();

	void Pause_OnEnter();
	void Pause_OnUpdate(float timestep);
	void Pause_OnRender();
	void Pause_OnExit();
public:
	Game();	
	~Game();

	bool Initialise(Direct3D* renderer, AudioSystem* audio, InputController* input); //The initialise method will load all of the content for the game (meshes, textures, etc.)

	void Update(float timestep);	//The overall Update method for the game. All gameplay logic will be done somewhere within this method
	void Render();					//The overall Render method for the game. Here all of the meshes that need to be drawn will be drawn

	void Shutdown(); //Cleanup everything we initialised
};

#endif