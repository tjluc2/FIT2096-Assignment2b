#include "GameObject.h"

GameObject::GameObject(Mesh* mesh, Shader* shader, Vector3 position, Texture* texture) {
	m_mesh = mesh;
	m_shader = shader;
	m_position = position;
	m_texture = texture;

	m_rotX = m_rotY = 0.0f;
	m_rotZ = 0.5f;
	SetUniformScale(0.5f);
}

GameObject::~GameObject() {

}

void GameObject::Update(float timestep) {

}


void GameObject::Render(Direct3D* renderer, Camera* cam) {
	if (m_mesh) 
	{
		m_world = Matrix::CreateScale(m_scaleX, m_scaleY, m_scaleZ) * Matrix::CreateFromYawPitchRoll(m_rotY, m_rotX, m_rotZ) * Matrix::CreateTranslation(m_position);
		m_mesh->Render(renderer, m_shader, m_world, cam, m_texture);
	}
}