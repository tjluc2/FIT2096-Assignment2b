#include "GameWorld.h"

GameWorld::GameWorld()
{
	m_mesh = NULL;
	m_texture = NULL;
	m_shader = NULL;
	m_texture = NULL;
}

GameWorld::GameWorld(MeshManager* meshManager, Shader* shader, TextureManager* textureManager)
{
	m_mesh = meshManager->GetMesh("Assets/Meshes/ground.obj");
	m_tileMesh = meshManager->GetMesh("Assets/Meshes/wall_tile.obj");
	m_shader = shader;
	m_texture = textureManager->GetTexture("Assets/Textures/ground.png");
	m_tileTexture = textureManager->GetTexture("Assets/Textures/tile_purple.png");
	m_position = Vector3::Zero;
	m_rotX = m_rotY = m_rotZ = 0.0f;
	m_scaleX = m_scaleY = m_scaleZ = 1.0f;

	AddWalls();
	AddObstacles();
}

GameWorld::~GameWorld()
{
}

void GameWorld::Update(float timestep)
{
}

void GameWorld::Render(Direct3D* render, Camera* camera)
{
	
	if (m_mesh) {
		m_world = Matrix::CreateScale(m_scaleX, m_scaleY, m_scaleZ) * Matrix::CreateFromYawPitchRoll(m_rotY, m_rotX, m_rotZ) * Matrix::CreateTranslation(m_position);
		m_mesh->Render(render, m_shader, m_world, camera, m_texture);
	} 
	//Render tiles
	for (int i = 0; i < tiles.size(); i++)
	{
		tiles[i]->Render(render, camera);
	}
	
	for (int i = 0; i < obstacles.size(); i++)
	{
		obstacles[i]->Render(render, camera);
	}
}

void GameWorld::AddWalls()
{
	// Add walls surrounding game world

	// Outer walls vertical 
	for (unsigned int z = 0; z < BOARD_Z + 1; z++)
	{
		// Left
		tiles.push_back(new Tile(m_tileMesh,
			m_shader,
			m_tileTexture,
			Vector3(-1, 0, z)));

		// Right
		tiles.push_back(new Tile(m_tileMesh,
			m_shader,
			m_tileTexture,
			Vector3(BOARD_X, 0, z)));
	} 

	//Outer walls horizontal
	for (unsigned int x = 0; x < BOARD_X; x++)
	{
		// Top 
		tiles.push_back(new Tile(m_tileMesh,
			m_shader,
			m_tileTexture,
			Vector3(x, 0, BOARD_Z)));

		// Bottom
		tiles.push_back(new Tile(m_tileMesh,
			m_shader,
			m_tileTexture,
			Vector3(x, 0, -1)));
	}

	for (int i = 0; i < tiles.size(); i++) {
		tiles[i]->SetYScale(2);
	}
}

void GameWorld::AddObstacles() 
{
	for (int i = 0; i < 40; i++) {
		int x = RandXPos();
		int z = RandXPos();

		
		obstacles.push_back(new Tile(m_tileMesh,
			m_shader,
			m_tileTexture,
			Vector3(x, 0, z)));
		obstacles[i]->SetYScale(3.0f);
		obstacles[i]->SetXScale(2.0f);
	}
}

int GameWorld::GetBoardSize()
{
	return BOARD_X * BOARD_Z;
}

int GameWorld::GetXSize()
{
	return BOARD_X;
}

int GameWorld::GetZSize()
{
	return BOARD_Z;
}

float GameWorld::RandXPos()
{
	return rand() % BOARD_X + 2;
}

float GameWorld::RandZPos()
{
	return rand() % BOARD_Z + 2;
}

std::vector<Tile*> GameWorld::GetWallTiles()
{
	return tiles;
}

std::vector<Tile*> GameWorld::GetObstacles()
{
	return obstacles;
}