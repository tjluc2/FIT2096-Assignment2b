#ifndef GAME_WORLD_H
#define GAME_WORLD_H

#include "MeshManager.h"
#include "TextureManager.h"
#include "GameObject.h"
#include "Tile.h"

class GameWorld
{
private:
	Matrix m_world;
	Mesh* m_mesh;
	Mesh* m_tileMesh;
	Texture* m_texture;
	Texture* m_tileTexture;
	Shader* m_shader;

	std::vector<Tile*> tiles;				//Used for walls
	std::vector<Tile*> obstacles;

	Vector3 m_position;

	float m_rotX, m_rotY, m_rotZ;
	float m_scaleX, m_scaleY, m_scaleZ;

	const static int BOARD_X = 80;
	const static int BOARD_Z = 70;

	void AddWalls();
public:
	GameWorld();
	GameWorld(MeshManager* meshManager, Shader* shader, TextureManager* textureManager);
	~GameWorld();

	void Update(float timestep);
	void Render(Direct3D* render, Camera* camera);

	void AddObstacles();
	int GetBoardSize();
	int GetXSize();
	int GetZSize();
	float RandXPos();
	float RandZPos();

	std::vector<Tile*> GetWallTiles();
	std::vector<Tile*> GetObstacles();

};

#endif