#include "Monster.h"
#include <iostream>
#include <math.h>

Monster::Monster(Mesh* mesh, Shader* shader, InputController* input, Vector3 position, Texture* texture, int damage, int reward) {
	m_mesh = mesh;
	m_shader = shader;
	m_input = input;
	m_position = position;
	m_texture = texture;

	m_rotX = m_rotY = m_rotZ = 0.0f;
	SetUniformScale(1.0f);

	m_moveSpeed = 1.5f;
	m_rotateSpeed = 1.0f;

	m_damage = damage;
	m_reward = reward;
}

Monster::~Monster() {

}

void Monster::InitRotation(Vector3 monsterPos, int i) {
	//Set intiial rotation of enemy to face player
	monsterPos = -monsterPos;
	Vector3 localForward = Vector3(0, 0, 1);				//Local forward vector of enemy.
	Vector3 distA = Vector3::Zero - monsterPos;			//Distance vector between origin and enemy.
	Vector3 distB = Vector3::Zero - localForward;	//Distance vector between origin and local forward.

	double dotProd = distA.Dot(distB);		//Dot product

	double denom1 = sqrt(pow(distA.x, 2) + pow(distA.y, 2) + pow(distA.z, 2));
	double denom2 = sqrt(pow(distB.x, 2) + pow(distB.y, 2) + pow(distB.z, 2));

	double angle = acos(dotProd / (abs(denom1 * denom2)));		//Cosine rule to find angle, angle = a.b / |a| * |b|

	m_rotY -= ToRadians(XMConvertToDegrees(angle));			//Adjust rotation according to angle
}

void Monster::SetRotation(Vector3 playerPos, Vector3 monsterPos, Vector3 prevPos, int i)
{
	if (i == 1) {
		Vector3 worldForward = Vector3(0, 0, 1);
		Matrix heading = Matrix::CreateRotationY(m_rotY);
		Vector3 localForward = Vector3::TransformNormal(worldForward, heading);			//Current local forward of monster

		Vector3 newPos = playerPos - prevPos;			//Distance between previous position and new position

		Vector3 monToNew = newPos - (-localForward);		//Distance between monster and new player position

		double dotProd = localForward.Dot(monToNew);		//Dot product

		double denom1 = sqrt(pow(localForward.x, 2) + pow(localForward.y, 2) + pow(localForward.z, 2));
		double denom2 = sqrt(pow(monToNew.x, 2) + pow(monToNew.y, 2) + pow(monToNew.z, 2));

		double angle = acos(dotProd / (abs(denom1 * denom2)));		//Cosine rule to find angle, angle = a.b / |a| * |b|

		if (monsterPos.z >= playerPos.z) {			//If above
			if (monsterPos.x >= playerPos.x) {			//If left
				if (newPos.x == 1 || newPos.x == -1) {
					m_rotY -= ToRadians(XMConvertToDegrees(angle));
				}
				else if (newPos.z == 1 || newPos.z == -1) {
					m_rotY += ToRadians(XMConvertToDegrees(angle));
				}
			}
			if (monsterPos.x == playerPos.x) {		//If same row
				if (newPos.x == -1) {
					m_rotY -= ToRadians(XMConvertToDegrees(angle));
				}
				else if (newPos.z == -1) {
					m_rotY += ToRadians(XMConvertToDegrees(angle));
				}
			}
			if (monsterPos.x <= playerPos.x) {			//If right
				if ((newPos.z == 1 || newPos.z == -1)) {
					m_rotY -= ToRadians(XMConvertToDegrees(angle));
				}
				else if (newPos.x == 1 || newPos.x == -1) {
					m_rotY += ToRadians(XMConvertToDegrees(angle));
				}
			}
		}

		if (monsterPos.z == playerPos.z) {		//If equal column
			if (newPos.x == 1) {
				m_rotY -= ToRadians(XMConvertToDegrees(angle));
			}
			else if (newPos.z == 1) {
				;
				m_rotY += ToRadians(XMConvertToDegrees(angle));
			}
		}

		if (monsterPos.z <= playerPos.z) {			//If below
			if (monsterPos.x >= playerPos.x) {		//If left
				if (newPos.x == 1 || newPos.z == -1) {
					m_rotY -= ToRadians(XMConvertToDegrees(angle));
				}
				else if (newPos.z == 1 || newPos.x == -1) {
					m_rotY += ToRadians(XMConvertToDegrees(angle));
				}
			}
			if (monsterPos.x == playerPos.x) {			//If equal row
				if (newPos.x == -1) {
					m_rotY -= ToRadians(XMConvertToDegrees(angle));
				}
				else if (newPos.z == -1) {
					m_rotY += ToRadians(XMConvertToDegrees(angle));
				}
			}
			if (monsterPos.x >= playerPos.x) {		//If right
				if (newPos.z == 1 || newPos.z == -1) {
					m_rotY -= ToRadians(XMConvertToDegrees(angle));
				}
				else if (newPos.x == -1 || newPos.x == 1) {
					m_rotY += ToRadians(XMConvertToDegrees(angle));
				}
			}
		} 
	}
	
} 

void Monster::Update(float timestep) {

}

void Monster::Render(Direct3D* renderer, Camera* cam) {
	if (m_mesh) {
		m_world = Matrix::CreateScale(m_scaleX, m_scaleY, m_scaleZ) * Matrix::CreateFromYawPitchRoll(m_rotY, m_rotX, m_rotZ) * Matrix::CreateTranslation(m_position);
		m_mesh->Render(renderer, m_shader, m_world, cam, m_texture);
	}
}

