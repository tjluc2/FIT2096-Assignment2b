#include "Monster.h"
#include <iostream>
#include <math.h>
#include <conio.h>

Monster::Monster()
{
}

Monster::Monster(Mesh* mesh, Shader* shader, Texture* texture, Vector3 position, Player* player, int damage, int reward, GameWorld* gameWorld, std::vector<Bullet*> bullets)
	: PhysicsObject(mesh, shader, texture, position) {
	m_player = player;
	m_gameWorld = gameWorld;
	m_bullets = bullets;

	bullets_left = bullets.size();

	m_moveSpeed = 0.009f;
	m_rotateSpeed = 2.0f;
	m_friction = 0.2f;

	m_damage = damage;
	m_reward = reward;

	x = z = 0;

	m_boundingBox = CBoundingBox(m_position + m_mesh->GetMin(), m_position + m_mesh->GetMax());
}

Monster::~Monster()
{
}


void Monster::Update(float timestep)
{
	// Vector from enemy to player
	Vector3 directionToPlayer = m_player->GetPosition() - m_position;

	// Normalize the vector to get a vector of unit length 
	directionToPlayer.Normalize();

	// Calculate the angle the enemy should be facing
	m_rotY = atan2(directionToPlayer.x, directionToPlayer.z);

	SetYRotation(m_rotY);

	
	double currentTime = GetTickCount() - startTime;
	if (currentTime >= shoot_interval)			//Monster shoots at player
	{
		if (bullets_left > 0)
		{
			int i = bullets_left - 1;
			m_bullets[i]->SetPosition(m_position + Vector3(0, 1.5, 0));
			m_bullets[i]->SetYRotation(m_rotY);
			m_bullets[i]->shoot(directionToPlayer);
			bullets_left -= 1;
			startTime = GetTickCount();
		}
		if (m_health <= 0) {
			Respawn();
		}
	} 

	if (m_damage == 2) {
		runAway();
	}
	else if (m_damage == 4) {
		randomMove();
	}
	else if (m_damage == 6)
	{
		chasePlayer();
	}
	else if (m_damage == 8)
	{
		blockPlayer();
	} else if (m_damage == 10) {
		bail();
	}  

	m_boundingBox.SetMin(m_position + m_mesh->GetMin());
	m_boundingBox.SetMax(m_position + m_mesh->GetMax());

	PhysicsObject::Update(timestep);
}

void Monster::runAway()
{
	// Enemy #1 will constantly run away from the player	- GETS STUCK IN CORNER
	Vector3 toTarget = -m_player->GetPosition() + m_position;
	toTarget.Normalize();

	ApplyForce(toTarget * m_moveSpeed * 0.5);
}

void Monster::randomMove()
{
	//Enemy #2 will constantly move to a random spot on the board - NOT WORKING
	if (x == 0 & z == 0) 
	{
		x = m_gameWorld->RandXPos();
		z = m_gameWorld->RandZPos();
	}

	if (m_position.x - x < 1 && m_position.z - z < 1) {
		x = m_gameWorld->RandXPos();
		z = m_gameWorld->RandZPos();
	}

	Vector3 toTarget = -m_position + Vector3(x, 0, z);
	toTarget.Normalize();

	ApplyForce(toTarget * m_moveSpeed * 0.4);

}

void Monster::chasePlayer()
{
	// Enemy #3 will constantly chase the player 
	Vector3 toTarget = -m_position + m_player->GetPosition();
	toTarget.Normalize();

	ApplyForce(toTarget * m_moveSpeed * 0.3);
}


void Monster::blockPlayer()
{
	//Enemy #4 will constantly move to a spot in front of the player
	Vector3 playerPos = m_player->GetPosition();

	//Get local forward of player
	Vector3 worldForward = Vector3(0, 0, 3);

	float player_rotY = m_player->GetYRotation();

	Matrix heading = Matrix::CreateRotationY(player_rotY);

	//Move enemy toward local forward of player position
	Vector3 localForward = playerPos + Vector3::TransformNormal(worldForward, heading);

	Vector3 toTarget = -m_position + localForward;
	toTarget.Normalize();

	ApplyForce(toTarget * m_moveSpeed * 0.2);
}

void Monster::bail()
{
	//Enemy #5 will run awway from the player once the player is in a close proximity - NOT WORKING
	Vector3 pos = m_player->GetPosition();
	
	if (m_position.x - pos.x < 3) 
	{
		randomMove();
	} else if (m_position.z - pos.z < 3) 
	{
		randomMove();
	}
}

void Monster::OnBulletCollisionEnter(Bullet* bullet)
{
	//When bullet collides with monster, does random amount of damage to health
	int damage = bullet->getDamage();
	m_health -= damage;
	if (m_health <= 0) {
		m_player->SetReward(m_reward);
		m_player->SetDefeated();
	}
}


void Monster::OnWallCollisionEnter(Tile* tile, int x, int z)
{
	if (m_position.z < 0)
	{
		m_position.z = 0;
	}

	if (m_position.z > z - 1)
	{
		m_position.z = z - 1;
	}

	if (m_position.x < 0)
	{
		m_position.x = 0;
	}

	if (m_position.x > x - 1)
	{
		m_position.x = x - 1;
	}
}

void Monster::OnObstacleCollisionEnter(Tile* obstacle)
{
	ApplyForce((m_position - obstacle->GetPosition()) * 0.01f);			//Original 0.4
}

void Monster::Respawn() {
	m_health = 10;
}
