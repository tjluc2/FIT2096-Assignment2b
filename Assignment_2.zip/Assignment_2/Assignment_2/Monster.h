#ifndef MONSTER_H
#define MONSTER_H

#include "PhysicsObject.h"
#include "Player.h"
#include "GameWorld.h"

class Monster : public PhysicsObject {
private:
	Player* m_player;

	GameWorld* m_gameWorld;
	CBoundingBox m_boundingBox;

	std::vector<Bullet*> m_bullets;

	float m_moveSpeed;
	float m_rotateSpeed;
	int m_health = 10;
	int bullets_left;
	int shoot_interval;
	int x, z;
	bool dead;
	int m_damage;
	int m_reward;

	double startTime = GetTickCount();
	double startTime2 = GetTickCount();

public:
	Monster();
	Monster(Mesh* mesh, Shader* shader, Texture* texture, Vector3 position, Player* player, int damage, int reward, GameWorld* gameWorld, std::vector<Bullet*> bullets);
	~Monster();

	void Update(float timestep);
	void runAway();						//Monster #1 will constantly run away from player
	void randomMove();					//Monster #2 will constantly move to a random position
	void chasePlayer();					//Monster #3 will constantly chase player
	void blockPlayer();					//Monster #4 will constantly try to move to a position in front of the player
	void bail();						//Monster #5 will run away once the player is in close proximity

	void OnBulletCollisionEnter(Bullet* bullet);
	void OnWallCollisionEnter(Tile* tile, int x, int z);
	void OnObstacleCollisionEnter(Tile* tile);
	int getHealth() { return m_health;  }
	void SetShootInterval(int interval) { shoot_interval = interval; }
	void Respawn();

	CBoundingBox GetBounds() { return m_boundingBox; }
};

#endif