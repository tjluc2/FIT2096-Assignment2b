#include "PhysicsObject.h"
#include <iostream> 

PhysicsObject::PhysicsObject()
{
}

PhysicsObject::PhysicsObject(Mesh* mesh, Shader* shader, Vector3 position) :
	GameObject(mesh, shader, position) 
{
	m_velocity = Vector3::Zero;
	m_acceleration = Vector3::Zero;
}


PhysicsObject::PhysicsObject(Mesh* mesh, Shader* shader, Texture* texture, Vector3 position) :
	GameObject(mesh, shader, texture, position)
{
	m_velocity = Vector3::Zero;
	m_acceleration = Vector3::Zero;
}

void PhysicsObject::Update(float timestep)
{
	ApplyFriction(m_friction); 

	m_velocity += m_acceleration;

	m_position += m_velocity;

	m_acceleration = Vector3::Zero;
}


void PhysicsObject::ApplyForce(Vector3 force)
{
	m_acceleration += force;
}

void PhysicsObject::ApplyFriction(float strength)
{
	ApplyForce(-m_velocity * strength);
}



