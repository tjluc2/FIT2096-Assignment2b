#ifndef PHYSICS_OBJECT_H
#define PHYSICS_OBJECT_H

#include "GameObject.h"

class PhysicsObject : public GameObject
{
protected:
	Vector3 m_velocity;
	Vector3 m_acceleration;

	float m_friction;

	void ApplyForce(Vector3 force);
	void ApplyFriction(float strength);
public:
	PhysicsObject();
	PhysicsObject(Mesh* mesh, Shader* shader, Vector3 position);
	PhysicsObject(Mesh* mesh, Shader* shader, Texture* texture, Vector3 position);

	virtual void Update(float timestep);
	void OnWallCollisionEnter(GameObject* wall);
};

#endif