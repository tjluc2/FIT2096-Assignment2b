#include "Player.h"
#include <iostream>


/* This is for when we want to add a texture to the object. */
Player::Player(Mesh* mesh, Shader* shader, InputController* input, Texture* texture, Vector3 position) {
	m_mesh = mesh;
	m_shader = shader;
	m_position = position;
	m_input = input;
	m_texture = texture;

	m_rotX = m_rotY = m_rotZ = 0.0f;
	SetUniformScale(0.5f);

	m_health = 10;
	m_moveSpeed = 1.0f;
	m_rotateSpeed = 1.0f;
}

Player::~Player() {

}

void Player::Update(float timestep) {

}

void Player::Render(Direct3D* renderer, Camera* cam) {
	if (m_mesh)
	{
		m_world = Matrix::CreateScale(m_scaleX, m_scaleY, m_scaleZ) * Matrix::CreateFromYawPitchRoll(m_rotY, m_rotX, m_rotZ) * Matrix::CreateTranslation(m_position);
		m_mesh->Render(renderer, m_shader, m_world, cam, m_texture);
	}
}

bool Player::checkPos(std::vector<std::pair<int, int>> disabledTiles, Vector3 nextPos) {
	//Checks for disabled tiles. Returns true if player can move.
	for (int i = 0; i < disabledTiles.size(); i++) {
		if ((int(nextPos.z) == disabledTiles[i].first) && (int(nextPos.x) == disabledTiles[i].second)) {
			return false;
		}
	}
	return true;
}

bool Player::checkEnd(std::vector<std::pair<int, int>> disabledTiles, int x, int z) {
	//Checks if player is surrounded by disabled tiles
	int count = 0;
	for (int i = 0; i < disabledTiles.size(); i++) {
		if ((m_position.x + 1 == disabledTiles[i].first) && (m_position.z == disabledTiles[i].second)) {
			count += 1;
		}
		if ((m_position.x - 1 == disabledTiles[i].first) && (m_position.z == disabledTiles[i].second)) {
			count += 1;
		}
		if ((m_position.x == disabledTiles[i].first) && (m_position.z + 1 == disabledTiles[i].second)) {
			count += 1;
		}
		if ((m_position.x == disabledTiles[i].first) && (m_position.z - 1 == disabledTiles[i].second)) {
			count += 1;
		}
	}

	//Checks if player is next to wall
	if (m_position.x - 1 == -1) {
		count += 1;
	} 
	if (m_position.x + 1 == x) {
		count += 1;
	} 
	if (m_position.z - 1 == -1) {
		count += 1; 
	} 
	if (m_position.z + 1 == z) {
		count += 1;
	}
	if (count >= 4) {
		return false;
	}
	return true;
}


void Player::movePlayer(int x, int z, std::vector<std::pair<int, int>> disabledTiles) {

	Vector3 worldForward = Vector3(0, 0, 1);
	Matrix heading = Matrix::CreateRotationY(m_rotY);
	Vector3 localForward = Vector3::TransformNormal(worldForward, heading);
	Vector3 nextPos;

	if (m_input->GetKeyDown('D')) {
		rotation += 90;
		m_rotY += ToRadians(90);
	} else if (m_input->GetKeyDown('A')) {
		rotation -= 90;
		m_rotY -= ToRadians(90);
	} else if (m_input->GetKeyDown('W')) {
		if (rotation == 0) {				//If facing forward in world space, check next pos in front
			nextPos = Vector3(m_position.z + 1, 0, m_position.x);
		}
		else if (rotation == 90 || rotation == -270) {			//Checks next pos on right side in reference to world space
			nextPos = Vector3(m_position.z, 0, m_position.x + 1.0f);
		}
		else if (rotation == 180 || rotation == -180) {			//Checks next pos behing player in reference to world space
			nextPos = Vector3(m_position.z - 1, 0, m_position.x);
		}
		else if (rotation == -90 || rotation == 270) {		//Checks next pos on left of player in reference to world space
			nextPos = Vector3(m_position.z, 0, m_position.x - 1.0f);
		}
		if (checkPos(disabledTiles, nextPos) == true) {			//If next pos is available, move player
			m_position += localForward * m_moveSpeed;
		}
	} 
	if (rotation == 360 || rotation == -360) {
		rotation = 0;
	}

	//Stops player from going outside z range
	if (m_position.z < 0) {
		m_position.z = 0;
	}
	if (m_position.z > z-1) {
		m_position.z = z-1;
	}

	//Stops player from going outside x range
	if (m_position.x < 0) {
		m_position.x = 0;
	} 
	if (m_position.x > x-1) {
		m_position.x = x-1;
	}
	m_position = Vector3(round(m_position.x), 0, round(m_position.z)); 
	m_world = Matrix::CreateScale(Vector3(m_scaleY, m_scaleX, m_scaleZ)) * Matrix::CreateTranslation(m_position);   
}

void Player::increaseHealth() {
	m_health += 1;
}

void Player::transportPlayer(std::vector<std::pair<int, int>> blueTiles) {
	int randPos = rand() % blueTiles.size();
	m_position = Vector3(blueTiles[randPos].first, 0, blueTiles[randPos].second);
}

int Player::monsterBattle(Monster* monster) {
	int monster_damage = monster->GetDamage();
	m_health -= monster_damage;
	if (m_health <= 0) {
		return 0;				//Indicates game over
	}
	m_defeated += 1;
	int monster_reward = monster->GetReward();
	m_strength += monster_reward;
	return m_health;						//Value to decrease health bar by
}

int Player::getHealth() {
	return m_health;
}