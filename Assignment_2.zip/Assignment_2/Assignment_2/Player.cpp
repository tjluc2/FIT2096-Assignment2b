#include "Player.h"
#include "MeshManager.h"
#include <iostream>


Player::Player() 
{
	m_input = NULL;
	m_moveSpeed = 0.002f;

	m_health = 10.0f;
	m_defeated = 0;
	m_reward;
}

Player::Player(Mesh* mesh, Shader* shader, InputController* input,  Vector3 position, std::vector<Bullet*> bullets, AudioSystem* audio) :
PhysicsObject(mesh, shader, position) {
	m_input = input;
	m_bullets = bullets;

	m_health = 10;
	m_moveSpeed = 0.009f;
	m_rotateSpeed = 2.0f;
	m_friction = 0.1f;
	
	bullets_left = 20;

	m_boundingBox = CBoundingBox(m_position + m_mesh->GetMin(), m_position + m_mesh->GetMax());

	m_audio = audio;

	//m_engineSound = m_audio->Play("Assets/Sounds/drumloop.wav", true);
	/*
	if (m_engineSound)
	{
		m_engineSound->SetLoopCount(-1);
		m_engineSound->SetIs3D(true);
		m_engineSound->SetMinMaxDistance(30.0f, 200.0f);
		m_engineSound->SetPaused(false);
	} */
}

Player::~Player() 
{
	if (m_engineSound)
	{
		delete m_engineSound;
		m_engineSound = NULL;
	}
}

void Player::Update(float timestep)
{
	Vector3 worldForward = Vector3(0, 0, 1);

	Matrix heading = Matrix::CreateRotationY(m_rotY);

	Vector3 localForward = Vector3::TransformNormal(worldForward, heading);

	// Rotation based on 'A' and 'D' keys
	if (m_input->GetKeyHold('A'))
	{
		m_rotY -= m_rotateSpeed * timestep;
	}

	if (m_input->GetKeyHold('D'))
	{
		m_rotY += m_rotateSpeed * timestep;
	} 

	//Move player forward
	if (m_input->GetKeyHold('W'))
	{
		ApplyForce(localForward * m_moveSpeed);
	}
	m_boundingBox.SetMin(m_position + m_mesh->GetMin());
	m_boundingBox.SetMax(m_position + m_mesh->GetMax());

	PhysicsObject::Update(timestep);
}

void Player::OnHealthCollisionEnter(DynamicObject* health) 
{
	if (m_health < MAX_HEALTH)
	{
		m_health += 1;
	}
}

void Player::OnWallCollisionEnter(Tile* tile, int x, int z)
{
	if (m_position.z < 0)
	{
		m_position.z = 0;
	}

	if (m_position.z > z-1)
	{
		m_position.z = z-1;
	} 

	if (m_position.x < 0)
	{
		m_position.x = 0;
	}
	
	if (m_position.x > x-1)
	{
		m_position.x = x-1;
	} 
} 

void Player::OnObstacleCollisionEnter(Tile* obstacle)
{
	ApplyForce((m_position - obstacle->GetPosition()) * 0.03f);		
	m_velocity = Vector3::Zero;
}

void Player::SetBullets(int bullets) {
	bullets_left += bullets;
	int reset = 0;
	for (int i = 0; i < bullets_left; i++) {
		if (m_bullets[i]->getUsed() == true && reset <=2) {
 			m_bullets[i]->setReuse();					//Sets bullet inUse back to false so it can be used again
			reset += 1;
		}
	}
}

void Player::shoot(Vector3 bulletlookAt, float heading) {
	int bullets;
	for (int i = 0; i < m_bullets.size(); i++) {
		if (m_bullets[i]->getUsed() == false) {
			m_bullets[i]->SetPosition(m_position + Vector3(0, 1, 0));
			m_bullets[i]->SetYRotation(heading);
			m_bullets[i]->setUsed();										//Bullet is in use
			m_bullets[i]->shoot(bulletlookAt);
			bullets_left -= 1;
			break;
		}
	}
}