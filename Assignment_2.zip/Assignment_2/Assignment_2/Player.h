#ifndef PLAYER_H
#define PLAYER_H

#include "Direct3D.h"
#include "InputController.h"
#include "Mesh.h"
#include "PhysicsObject.h"
#include "Collisions.h"
#include "DynamicObject.h"
#include "MeshManager.h"
#include "TextureManager.h"
#include "AudioSystem.h"
#include "Bullet.h"
#include <vector>

class Player : public PhysicsObject {
private:
	InputController* m_input;
	CBoundingBox m_boundingBox;
	
	std::vector<Bullet*> m_bullets;
	Vector3 m_lookAt;

	AudioSystem* m_audio;
	AudioClip* m_engineSound;

	int bullets_left;

	float m_moveSpeed;
	float m_rotateSpeed;

	int m_defeated;
	int m_reward;

	int m_health;			//Player health
	int MAX_HEALTH = 10;
public:
	Player();
	Player(Mesh* mesh, Shader* shader, InputController* input, Vector3 position, std::vector<Bullet*> bullets, AudioSystem* audio);
	~Player();

	void Update(float timestep);
	
	int GetHealth() { return m_health; }			//Returns amount of health player has
	void SetHealth(int damage) { m_health -= damage;  }				//When player is hurt
	void SetReward(int reward) { m_reward += reward; }
	void SetDefeated() { m_defeated += 1;  }
	int GetReward() { return m_reward; }
	int GetDefeated() { return m_defeated; }
	int GetBulletsLeft() { return bullets_left;  }		//Returns amount of bullets the player has left
	void SetBullets(int bullet);
	void increaseHealth() { m_health += 1; }					//When player collects health capsule

	void OnHealthCollisionEnter(DynamicObject* health);			//Checks if player is colliding with health capsule
	void OnWallCollisionEnter(Tile* tile, int x, int z);
	void OnObstacleCollisionEnter(Tile* tile);

	void SetLookAt(Vector3 lookAt) { m_lookAt = lookAt; }
	void shoot(Vector3 bulletlookAt, float heading);
	CBoundingBox GetBounds() { return m_boundingBox; }

};

#endif