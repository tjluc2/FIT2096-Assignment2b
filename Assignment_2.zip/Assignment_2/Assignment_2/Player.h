#ifndef PLAYER_H
#define PLAYER_H

#include "Direct3D.h"
#include "InputController.h"
#include "Mesh.h"
#include "Monster.h"
#include "Tile.h"
#include <vector>

class Player {
private:
	InputController* m_input;
	Vector3 m_position;
	Matrix m_world;
	Mesh* m_mesh;
	Texture* m_texture;
	Shader* m_shader;
	float m_rotX, m_rotY, m_rotZ;
	float m_scaleX, m_scaleY, m_scaleZ;
	float m_moveSpeed;
	float m_rotateSpeed;
	Vector3 movement;
	Vector3 nextPos;
	float rotation;

	std::vector<std::pair<int, int>> m_walkedOnBlue;		//Vector array of blue tiles player has used

	int m_health;			//Player health
	int m_strength;			//Player strength - collected by tiles travelled/battles with monsters
	int m_blueTiles = 0;		//Iterates through blueTiles list and gives next position of player
	int m_defeated;				//Number of monsters defeated
public:
	Player(Mesh* mesh, Shader* shader, InputController* input, Texture* texture, Vector3 position);
	//Player(Mesh* mesh, Shader* shader, Texture* texture, Vector2 position);
	~Player();

	void Update(float timestep);
	void Render(Direct3D* renderer, Camera* cam);

	//Accessors
	Vector3 GetPosition() { return m_position; }
	float GetXRotation() { return m_rotX; }
	float GetYRotation() { return m_rotY; }
	float GetZRotation() { return m_rotZ; }
	float GetXScale() { return m_scaleX; }
	float GetYScale() { return m_scaleY; }
	float GetZScale() { return m_scaleZ; }
	Mesh* GetMesh() { return m_mesh; }
	Texture* GetTexture() { return m_texture; }
	Shader* GetShader() { return m_shader; }

	//Mutators
	void SetPosition(Vector3 pos) { m_position = pos; }
	void SetXRotation(float xRot) { m_rotX = xRot; }
	void SetYRotation(float yRot) { m_rotY = yRot; }
	void SetZRotation(float zRot) { m_rotZ = zRot; }
	void SetXScale(float xScale) { m_scaleX = xScale; }
	void SetYScale(float yScale) { m_scaleY = yScale; }
	void SetZScale(float zScale) { m_scaleZ = zScale; }
	void SetUniformScale(float scale) { m_scaleX = m_scaleY = m_scaleZ = scale; }
	void SetMesh(Mesh* mesh) { m_mesh = mesh; }
	void SetTexture(Texture* texture) { m_texture = texture; }
	void SetShader(Shader* shader) { m_shader = shader; }


	int GetReward() { return m_strength;  }
	int GetDefeated() { return m_defeated;  }

	void transportPlayer(std::vector<std::pair<int, int>> blueTiles);			//Transports player between blue tiles	
	void movePlayer(int x, int z, std::vector<std::pair<int, int>> disabledTiles);		//Move player in any direction based on input
	bool checkPos(std::vector<std::pair<int, int>> disabledTiles, Vector3 nextPos);		//Returns array of next positions.
	void increaseHealth();							//Increase health if player steps on green tile
	int monsterBattle(Monster* monster);				//Handles battle mechanism
	bool checkEnd(std::vector<std::pair<int, int>> disabledTiles, int x, int z);		//Checks that player can still move
	int getHealth();			//Returns amount of health player has
};

#endif