#include "Camera.h"
#include "Player.h"

class SurveillanceCamera : public Camera
{
private:
	Player* m_lookAtTarget;

	//Follow strength of 0 means ignore target
	//Follow strength of 1 means looking directly at it
	float m_followStrength;
public:
	SurveillanceCamera();
	SurveillanceCamera(float followStrength);
	SurveillanceCamera(Player* target, float followStrength);

	void Update(float timestep);
	void SetTarget(Player* target) { m_lookAtTarget = target; }
};