#include "SurveillanceCamara.h"

SurveillanceCamera::SurveillanceCamera()
{
	m_lookAtTarget = NULL;
	m_followStrength = 1.0f;
}

SurveillanceCamera::SurveillanceCamera(float followStrength)
{
	m_lookAtTarget = NULL;
	m_followStrength = followStrength;
}

SurveillanceCamera::SurveillanceCamera(Player* target, float followStrength)
{
	m_lookAtTarget = target;
	m_followStrength = followStrength;
}

void SurveillanceCamera::Update(float timestep)
{
	Camera::Update(timestep);

	if (m_lookAtTarget != NULL)
	{
		SetLookAt(m_lookAtTarget->GetPosition() * m_followStrength);
	}
}
