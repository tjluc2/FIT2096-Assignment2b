#include "Tile.h"

Tile::Tile(Mesh* mesh, Shader* shader, Texture* texture, Vector3 position)
: GameObject(mesh, shader, texture) {
	m_mesh = mesh;
	m_shader = shader;
	m_position = position;
	m_texture = texture;

	SetUniformScale(1.0f);

	m_boundingBox = CBoundingBox(m_position + m_mesh->GetMin(), m_position + m_mesh->GetMax());
}

Tile::~Tile() {
	m_boundingBox.SetMin(m_position + m_mesh->GetMin());
	m_boundingBox.SetMax(m_position + m_mesh->GetMax());
}

void Tile::Update(float timestep) {

}
