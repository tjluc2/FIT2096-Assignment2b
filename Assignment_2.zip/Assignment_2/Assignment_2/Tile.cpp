#include "Tile.h"

Tile::Tile(Mesh* mesh, Shader* shader, InputController* input, Vector3 position, Texture* texture) {
	m_mesh = mesh;
	m_shader = shader;
	m_input = input;
	m_position = position;
	m_texture = texture;

	m_rotX = m_rotY = m_rotZ = 0.0f;
	SetUniformScale(1.0f);

	m_moveSpeed = 1.5f;
	m_rotateSpeed = 1.0f;
}

Tile::~Tile() {

}

void Tile::Update(float timestep) {

}

void Tile::Render(Direct3D* renderer, Camera* cam) {
	if (m_mesh) {
		m_world = Matrix::CreateScale(m_scaleX, m_scaleY, m_scaleZ) * Matrix::CreateFromYawPitchRoll(m_rotY, m_rotX, m_rotZ) * Matrix::CreateTranslation(m_position);
		m_mesh->Render(renderer, m_shader, m_world, cam, m_texture);
	}
}

