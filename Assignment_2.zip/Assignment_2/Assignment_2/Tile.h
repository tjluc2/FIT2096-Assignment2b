#ifndef TILE_H
#define TILE_H


#include "GameObject.h"

class Tile : public GameObject {
private:
	CBoundingBox m_boundingBox;
public:
	Tile(Mesh* mesh, Shader* shader, Texture* texture, Vector3 position);
	~Tile();

	void Update(float timestep);

	CBoundingBox GetBounds() { return m_boundingBox; }
};

#endif